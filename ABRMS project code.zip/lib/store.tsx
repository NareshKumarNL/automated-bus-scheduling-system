"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

// Define types for our data
export type Crew = {
  id: number
  name: string
  employeeId: string
  role: string
  isAvailable: boolean
  lastAssignment: string | null
  dailyAssignments: number
  isCheckedIn?: boolean
  checkInTime?: string
}

export type Bus = {
  id: number
  busNumber: string
  model: string
  capacity: number
  isAvailable: boolean
  status: string
  lastMaintenance: string
}

export type Route = {
  id: number
  routeNumber: string
  startPoint: string
  endPoint: string
  estimatedTime: number
  stops: number
  status: string
}

export type Schedule = {
  id: number
  routeNumber: string
  busNumber: string
  driver: string
  conductor: string
  departureTime: string
  status: string
}

export type Emergency = {
  id: number
  type: string
  busNumber: string
  location: string
  time: string
  status: string
  description: string
  resolvedTime?: string
}

export type Ticket = {
  id: number
  scheduleId: number
  passengerName: string
  passengerPhone: string
  passengerEmail: string
  passengerCount: number
  seatNumbers: number[]
  paymentMethod: string
  totalAmount: number
  bookingTime: string
  status: string
}

export type AnalyticsData = {
  revenue: number
  passengerCount: number
  onTimePerformance: number
  fuelEfficiency: number
  monthlyRevenue: number[]
  monthlyPassengers: number[]
  routePerformance: { route: string; performance: number }[]
  fleetUtilization: { busType: string; utilization: number }[]
}

// Define the shape of our global state
type AppState = {
  crews: Crew[]
  buses: Bus[]
  routes: Route[]
  schedules: Schedule[]
  emergencies: Emergency[]
  tickets: Ticket[]
  analytics: AnalyticsData
  selectedCrewId: number | null
  setCrews: (crews: Crew[]) => void
  setBuses: (buses: Bus[]) => void
  setRoutes: (routes: Route[]) => void
  setSchedules: (schedules: Schedule[]) => void
  setEmergencies: (emergencies: Emergency[]) => void
  setSelectedCrewId: (id: number | null) => void

  // CRUD Operations
  // Crew
  addCrew: (crew: Omit<Crew, "id">) => number
  updateCrew: (id: number, crew: Partial<Crew>) => void
  deleteCrew: (id: number) => void

  // Bus
  addBus: (bus: Omit<Bus, "id">) => void
  updateBus: (id: number, bus: Partial<Bus>) => void
  deleteBus: (id: number) => void

  // Route
  addRoute: (route: Omit<Route, "id">) => void
  updateRoute: (id: number, route: Partial<Route>) => void
  deleteRoute: (id: number) => void

  // Schedule
  addSchedule: (schedule: Omit<Schedule, "id">) => void
  updateSchedule: (id: number, schedule: Partial<Schedule>) => void
  deleteSchedule: (id: number) => void

  // Emergency
  addEmergency: (emergency: Omit<Emergency, "id" | "time" | "status">) => void
  updateEmergency: (id: number, emergency: Partial<Emergency>) => void
  deleteEmergency: (id: number) => void

  // Ticket
  bookTicket: (ticket: Omit<Ticket, "id">) => number

  // Crew operations
  checkInCrew: (crewId: number, checkInTime: string) => void
  checkOutCrew: (crewId: number) => void
}

// Sample initial data
const initialCrews: Crew[] = [
  {
    id: 1,
    name: "Rajesh Kumar",
    employeeId: "ST-D-1001",
    role: "Driver",
    isAvailable: true,
    lastAssignment: "2023-04-12T08:30:00",
    dailyAssignments: 2,
  },
  {
    id: 2,
    name: "Sunil Murugan",
    employeeId: "ST-D-1002",
    role: "Driver",
    isAvailable: false,
    lastAssignment: "2023-04-12T09:15:00",
    dailyAssignments: 3,
  },
  {
    id: 3,
    name: "Anand Rajan",
    employeeId: "ST-C-2001",
    role: "Conductor",
    isAvailable: true,
    lastAssignment: "2023-04-12T07:45:00",
    dailyAssignments: 1,
  },
  {
    id: 4,
    name: "Priya Lakshmi",
    employeeId: "ST-D-1003",
    role: "Driver",
    isAvailable: true,
    lastAssignment: "2023-04-11T18:30:00",
    dailyAssignments: 0,
  },
  {
    id: 5,
    name: "Vikram Chandran",
    employeeId: "ST-C-2002",
    role: "Conductor",
    isAvailable: true,
    lastAssignment: "2023-04-12T10:00:00",
    dailyAssignments: 2,
  },
]

const initialBuses: Bus[] = [
  {
    id: 1,
    busNumber: "TN-01-N-4532",
    model: "Ashok Leyland Viking",
    capacity: 40,
    isAvailable: true,
    status: "Active",
    lastMaintenance: "2023-03-15",
  },
  {
    id: 2,
    busNumber: "TN-01-N-7821",
    model: "Tata Marcopolo",
    capacity: 35,
    isAvailable: true,
    status: "Active",
    lastMaintenance: "2023-03-20",
  },
  {
    id: 3,
    busNumber: "TN-01-N-9023",
    model: "Ashok Leyland Viking",
    capacity: 40,
    isAvailable: false,
    status: "Maintenance",
    lastMaintenance: "2023-04-10",
  },
  {
    id: 4,
    busNumber: "TN-01-N-3421",
    model: "Volvo 8400",
    capacity: 45,
    isAvailable: true,
    status: "Active",
    lastMaintenance: "2023-02-28",
  },
  {
    id: 5,
    busNumber: "TN-01-N-6754",
    model: "Tata Marcopolo",
    capacity: 35,
    isAvailable: true,
    status: "Active",
    lastMaintenance: "2023-03-25",
  },
]

const initialRoutes: Route[] = [
  {
    id: 1,
    routeNumber: "423",
    startPoint: "Chennai",
    endPoint: "Coimbatore",
    estimatedTime: 420,
    stops: 12,
    status: "Active",
  },
  {
    id: 2,
    routeNumber: "392",
    startPoint: "Madurai",
    endPoint: "Trichy",
    estimatedTime: 180,
    stops: 8,
    status: "Active",
  },
  {
    id: 3,
    routeNumber: "107",
    startPoint: "Salem",
    endPoint: "Erode",
    estimatedTime: 90,
    stops: 5,
    status: "Diverted",
  },
  {
    id: 4,
    routeNumber: "522",
    startPoint: "Coimbatore",
    endPoint: "Ooty",
    estimatedTime: 150,
    stops: 10,
    status: "Active",
  },
  {
    id: 5,
    routeNumber: "238",
    startPoint: "Chennai",
    endPoint: "Vellore",
    estimatedTime: 150,
    stops: 7,
    status: "Active",
  },
]

const initialSchedules: Schedule[] = [
  {
    id: 1,
    routeNumber: "423",
    busNumber: "TN-01-N-4532",
    driver: "Rajesh Kumar",
    conductor: "Anand Rajan",
    departureTime: "2023-04-12T08:00:00",
    status: "Completed",
  },
  {
    id: 2,
    routeNumber: "392",
    busNumber: "TN-01-N-7821",
    driver: "Sunil Murugan",
    conductor: "Vikram Chandran",
    departureTime: "2023-04-12T08:15:00",
    status: "In Progress",
  },
  {
    id: 3,
    routeNumber: "107",
    busNumber: "TN-01-N-9023",
    driver: "Priya Lakshmi",
    conductor: "Neha Gupta",
    departureTime: "2023-04-12T08:30:00",
    status: "Scheduled",
  },
  {
    id: 4,
    routeNumber: "522",
    busNumber: "TN-01-N-3421",
    driver: "Anil Kapoor",
    conductor: "Rahul Verma",
    departureTime: "2023-04-12T08:45:00",
    status: "Scheduled",
  },
  {
    id: 5,
    routeNumber: "238",
    busNumber: "TN-01-N-6754",
    driver: "Deepak Sharma",
    conductor: "Sanjay Mishra",
    departureTime: "2023-04-12T09:00:00",
    status: "Scheduled",
  },
]

const initialEmergencies: Emergency[] = [
  {
    id: 1,
    type: "Breakdown",
    busNumber: "TN-01-N-4532",
    location: "Chennai Central",
    time: "2023-04-12T10:15:00",
    status: "Resolved",
    description: "Bus engine failure. Replacement bus dispatched.",
  },
  {
    id: 2,
    type: "Accident",
    busNumber: "TN-01-N-7821",
    location: "Trichy Bus Stand",
    time: "2023-04-12T09:30:00",
    status: "In Progress",
    description: "Minor collision with another vehicle. No injuries reported.",
  },
  {
    id: 3,
    type: "Medical",
    busNumber: "TN-01-N-9023",
    location: "Madurai Highway",
    time: "2023-04-11T14:45:00",
    status: "Resolved",
    description: "Passenger medical emergency. Ambulance dispatched.",
  },
]

const initialTickets: Ticket[] = [
  {
    id: 1,
    scheduleId: 1,
    passengerName: "Arun Kumar",
    passengerPhone: "9876543210",
    passengerEmail: "arun@example.com",
    passengerCount: 2,
    seatNumbers: [5, 6],
    paymentMethod: "card",
    totalAmount: 520,
    bookingTime: "2023-04-10T14:30:00",
    status: "Confirmed",
  },
  {
    id: 2,
    scheduleId: 2,
    passengerName: "Meena Sharma",
    passengerPhone: "8765432109",
    passengerEmail: "meena@example.com",
    passengerCount: 1,
    seatNumbers: [12],
    paymentMethod: "upi",
    totalAmount: 280,
    bookingTime: "2023-04-11T09:15:00",
    status: "Confirmed",
  },
]

const initialAnalytics: AnalyticsData = {
  revenue: 24563890,
  passengerCount: 1245632,
  onTimePerformance: 94.7,
  fuelEfficiency: 5.2,
  monthlyRevenue: [
    1800000, 1950000, 2100000, 2250000, 2400000, 2550000, 2700000, 2850000, 3000000, 3150000, 3300000, 3450000,
  ],
  monthlyPassengers: [95000, 98000, 102000, 105000, 108000, 112000, 115000, 118000, 122000, 125000, 128000, 132000],
  routePerformance: [
    { route: "423", performance: 96 },
    { route: "392", performance: 92 },
    { route: "107", performance: 88 },
    { route: "522", performance: 94 },
    { route: "238", performance: 90 },
  ],
  fleetUtilization: [
    { busType: "Ashok Leyland Viking", utilization: 85 },
    { busType: "Tata Marcopolo", utilization: 78 },
    { busType: "Volvo 8400", utilization: 92 },
  ],
}

// Create the context
const AppContext = createContext<AppState | undefined>(undefined)

// Create a provider component
export function AppProvider({ children }: { children: ReactNode }) {
  const [crews, setCrews] = useState<Crew[]>(initialCrews)
  const [buses, setBuses] = useState<Bus[]>(initialBuses)
  const [routes, setRoutes] = useState<Route[]>(initialRoutes)
  const [schedules, setSchedules] = useState<Schedule[]>(initialSchedules)
  const [emergencies, setEmergencies] = useState<Emergency[]>(initialEmergencies)
  const [tickets, setTickets] = useState<Ticket[]>(initialTickets)
  const [analytics, setAnalytics] = useState<AnalyticsData>(initialAnalytics)
  const [selectedCrewId, setSelectedCrewId] = useState<number | null>(null)

  // Load data from localStorage on initial render
  useEffect(() => {
    const storedCrews = localStorage.getItem("crews")
    const storedBuses = localStorage.getItem("buses")
    const storedRoutes = localStorage.getItem("routes")
    const storedSchedules = localStorage.getItem("schedules")
    const storedEmergencies = localStorage.getItem("emergencies")
    const storedTickets = localStorage.getItem("tickets")

    if (storedCrews) setCrews(JSON.parse(storedCrews))
    if (storedBuses) setBuses(JSON.parse(storedBuses))
    if (storedRoutes) setRoutes(JSON.parse(storedRoutes))
    if (storedSchedules) setSchedules(JSON.parse(storedSchedules))
    if (storedEmergencies) setEmergencies(JSON.parse(storedEmergencies))
    if (storedTickets) setTickets(JSON.parse(storedTickets))
  }, [])

  // Save data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("crews", JSON.stringify(crews))
    localStorage.setItem("buses", JSON.stringify(buses))
    localStorage.setItem("routes", JSON.stringify(routes))
    localStorage.setItem("schedules", JSON.stringify(schedules))
    localStorage.setItem("emergencies", JSON.stringify(emergencies))
    localStorage.setItem("tickets", JSON.stringify(tickets))
  }, [crews, buses, routes, schedules, emergencies, tickets])

  // Crew CRUD operations
  const addCrew = (crew: Omit<Crew, "id">) => {
    const newId = crews.length > 0 ? Math.max(...crews.map((c) => c.id)) + 1 : 1
    const newCrew = {
      ...crew,
      id: newId,
    }
    setCrews([...crews, newCrew])
    return newId
  }

  const updateCrew = (id: number, updatedCrew: Partial<Crew>) => {
    setCrews(crews.map((crew) => (crew.id === id ? { ...crew, ...updatedCrew } : crew)))
  }

  const deleteCrew = (id: number) => {
    setCrews(crews.filter((crew) => crew.id !== id))
  }

  // Bus CRUD operations
  const addBus = (bus: Omit<Bus, "id">) => {
    const newBus = {
      ...bus,
      id: buses.length > 0 ? Math.max(...buses.map((b) => b.id)) + 1 : 1,
    }
    setBuses([...buses, newBus])
  }

  const updateBus = (id: number, updatedBus: Partial<Bus>) => {
    setBuses(buses.map((bus) => (bus.id === id ? { ...bus, ...updatedBus } : bus)))
  }

  const deleteBus = (id: number) => {
    setBuses(buses.filter((bus) => bus.id !== id))
  }

  // Route CRUD operations
  const addRoute = (route: Omit<Route, "id">) => {
    const newRoute = {
      ...route,
      id: routes.length > 0 ? Math.max(...routes.map((r) => r.id)) + 1 : 1,
    }
    setRoutes([...routes, newRoute])
  }

  const updateRoute = (id: number, updatedRoute: Partial<Route>) => {
    setRoutes(routes.map((route) => (route.id === id ? { ...route, ...updatedRoute } : route)))
  }

  const deleteRoute = (id: number) => {
    setRoutes(routes.filter((route) => route.id !== id))
  }

  // Schedule CRUD operations
  const addSchedule = (schedule: Omit<Schedule, "id">) => {
    const newSchedule = {
      ...schedule,
      id: schedules.length > 0 ? Math.max(...schedules.map((s) => s.id)) + 1 : 1,
    }
    setSchedules([...schedules, newSchedule])

    // Update crew availability and assignments
    const updatedCrews = crews.map((crew) => {
      if (crew.name === schedule.driver || crew.name === schedule.conductor) {
        return {
          ...crew,
          isAvailable: false,
          lastAssignment: schedule.departureTime,
          dailyAssignments: crew.dailyAssignments + 1,
        }
      }
      return crew
    })
    setCrews(updatedCrews)

    // Update bus availability
    const updatedBuses = buses.map((bus) => {
      if (bus.busNumber === schedule.busNumber) {
        return {
          ...bus,
          isAvailable: false,
        }
      }
      return bus
    })
    setBuses(updatedBuses)
  }

  const updateSchedule = (id: number, updatedSchedule: Partial<Schedule>) => {
    setSchedules(schedules.map((schedule) => (schedule.id === id ? { ...schedule, ...updatedSchedule } : schedule)))
  }

  const deleteSchedule = (id: number) => {
    // Get the schedule to delete
    const scheduleToDelete = schedules.find((s) => s.id === id)

    // Free up crew and bus resources if the schedule is deleted
    if (scheduleToDelete) {
      // Update crew availability if they were assigned to this schedule
      const updatedCrews = crews.map((crew) => {
        if (crew.name === scheduleToDelete.driver || crew.name === scheduleToDelete.conductor) {
          return {
            ...crew,
            isAvailable: true,
            dailyAssignments: Math.max(0, crew.dailyAssignments - 1),
          }
        }
        return crew
      })
      setCrews(updatedCrews)

      // Update bus availability
      const updatedBuses = buses.map((bus) => {
        if (bus.busNumber === scheduleToDelete.busNumber) {
          return {
            ...bus,
            isAvailable: true,
          }
        }
        return bus
      })
      setBuses(updatedBuses)
    }

    // Delete the schedule
    setSchedules(schedules.filter((schedule) => schedule.id !== id))
  }

  // Emergency CRUD operations
  const addEmergency = (emergency: Omit<Emergency, "id" | "time" | "status">) => {
    const newEmergency = {
      ...emergency,
      id: emergencies.length > 0 ? Math.max(...emergencies.map((e) => e.id)) + 1 : 1,
      time: new Date().toISOString(),
      status: "In Progress",
    }
    setEmergencies([newEmergency, ...emergencies])

    // Update bus status if it's a breakdown or accident
    if (emergency.type === "Breakdown" || emergency.type === "Accident") {
      const updatedBuses = buses.map((bus) => {
        if (bus.busNumber === emergency.busNumber) {
          return {
            ...bus,
            status: emergency.type === "Breakdown" ? "Maintenance" : "Out of Service",
            isAvailable: false,
          }
        }
        return bus
      })
      setBuses(updatedBuses)
    }
  }

  const updateEmergency = (id: number, updatedEmergency: Partial<Emergency>) => {
    setEmergencies(
      emergencies.map((emergency) => (emergency.id === id ? { ...emergency, ...updatedEmergency } : emergency)),
    )

    // If emergency is being resolved, update bus status
    if (updatedEmergency.status === "Resolved") {
      const emergency = emergencies.find((e) => e.id === id)
      if (emergency) {
        // Update bus status when emergency is resolved
        const updatedBuses = buses.map((bus) => {
          if (bus.busNumber === emergency.busNumber) {
            // Only update status if the emergency type was breakdown or accident
            if (emergency.type === "Breakdown" || emergency.type === "Accident") {
              return {
                ...bus,
                status: "Active",
                isAvailable: true,
              }
            }
          }
          return bus
        })
        setBuses(updatedBuses)
      }
    }
  }

  const deleteEmergency = (id: number) => {
    setEmergencies(emergencies.filter((emergency) => emergency.id !== id))
  }

  // Ticket booking
  const bookTicket = (ticket: Omit<Ticket, "id">) => {
    const newId = tickets.length > 0 ? Math.max(...tickets.map((t) => t.id)) + 1 : 1
    const newTicket = {
      ...ticket,
      id: newId,
    }
    setTickets([...tickets, newTicket])

    // Update analytics
    setAnalytics({
      ...analytics,
      revenue: analytics.revenue + ticket.totalAmount,
      passengerCount: analytics.passengerCount + ticket.passengerCount,
      monthlyRevenue: analytics.monthlyRevenue.map((val, idx) =>
        idx === new Date().getMonth() ? val + ticket.totalAmount : val,
      ),
      monthlyPassengers: analytics.monthlyPassengers.map((val, idx) =>
        idx === new Date().getMonth() ? val + ticket.passengerCount : val,
      ),
    })

    return newId
  }

  // Check in a crew member
  const checkInCrew = (crewId: number, checkInTime: string) => {
    const updatedCrews = crews.map((crew) => {
      if (crew.id === crewId) {
        return {
          ...crew,
          isCheckedIn: true,
          checkInTime: checkInTime,
          isAvailable: false,
        }
      }
      return crew
    })
    setCrews(updatedCrews)
  }

  // Check out a crew member
  const checkOutCrew = (crewId: number) => {
    const updatedCrews = crews.map((crew) => {
      if (crew.id === crewId) {
        return {
          ...crew,
          isCheckedIn: false,
          checkInTime: null,
          isAvailable: true,
        }
      }
      return crew
    })
    setCrews(updatedCrews)
  }

  return (
    <AppContext.Provider
      value={{
        crews,
        buses,
        routes,
        schedules,
        emergencies,
        tickets,
        analytics,
        selectedCrewId,
        setCrews,
        setBuses,
        setRoutes,
        setSchedules,
        setEmergencies,
        setSelectedCrewId,
        addCrew,
        updateCrew,
        deleteCrew,
        addBus,
        updateBus,
        deleteBus,
        addRoute,
        updateRoute,
        deleteRoute,
        addSchedule,
        updateSchedule,
        deleteSchedule,
        addEmergency,
        updateEmergency,
        deleteEmergency,
        bookTicket,
        checkInCrew,
        checkOutCrew,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

// Custom hook to use the app context
export function useAppStore() {
  const context = useContext(AppContext)
  if (context === undefined) {
    throw new Error("useAppStore must be used within an AppProvider")
  }
  return context
}

// Add the missing export that's being referenced elsewhere in the codebase
export const useStore = useAppStore
