"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Bus, ArrowLeft, Lock, User, AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function CrewLoginPage() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [showCredentials, setShowCredentials] = useState(false)
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // In a real application, this would be an API call to authenticate
    // For demo purposes, we'll just simulate a login with default credentials
    setTimeout(() => {
      setIsLoading(false)
      if (username === "crew" && password === "crew123") {
        // Redirect to crew dashboard after successful login
        router.push("/crew-dashboard")
      } else {
        // For demo purposes, show the default credentials
        setShowCredentials(true)
      }
    }, 1000)
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-r from-purple-50 via-indigo-50 to-blue-50">
      <Link href="/" className="absolute left-4 top-4 md:left-8 md:top-8">
        <Button
          variant="ghost"
          className="flex items-center gap-2 text-slate-700 hover:text-blue-600 hover:bg-blue-50 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Button>
      </Link>
      <div className="mx-auto flex w-full flex-col justify-center space-y-6 sm:w-[350px]">
        <div className="flex flex-col space-y-2 text-center">
          <div className="flex justify-center">
            <div className="w-16 h-16 rounded-full bg-gradient-to-r from-purple-600 to-blue-600 flex items-center justify-center">
              <Bus className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900">Crew Login</h1>
          <p className="text-sm text-slate-600">Enter your credentials to access the crew dashboard</p>
        </div>
        <Card className="border-none shadow-xl">
          <CardHeader className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-t-lg">
            <CardTitle className="text-white text-center">Crew Access</CardTitle>
          </CardHeader>
          <form onSubmit={handleLogin}>
            <CardContent className="pt-6">
              <div className="grid gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="username" className="text-slate-700">
                    Username
                  </Label>
                  <div className="relative">
                    <User className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <Input
                      id="username"
                      placeholder="Enter your username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      required
                      className="pl-9 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="password" className="text-slate-700">
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="pl-9 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>

                {showCredentials && (
                  <Alert className="bg-blue-50 border-blue-200">
                    <AlertCircle className="h-4 w-4 text-blue-600" />
                    <AlertDescription className="text-blue-700">
                      Default credentials: username: <strong>crew</strong>, password: <strong>crew123</strong>
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
                type="submit"
                disabled={isLoading}
              >
                {isLoading ? "Logging in..." : "Login"}
              </Button>
            </CardFooter>
          </form>
        </Card>
        <div className="relative w-full h-[150px] rounded-lg overflow-hidden shadow-lg">
          <Image src="/placeholder.svg?height=300&width=800" alt="SmartTransit Crew" fill className="object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          <div className="absolute bottom-4 left-4 right-4 text-white">
            <h3 className="text-lg font-bold">Crew Portal</h3>
            <p className="text-sm text-white/80">Access your schedules and assignments</p>
          </div>
        </div>
        <p className="px-8 text-center text-sm text-slate-600">
          <Link href="/login" className="hover:text-blue-600 underline underline-offset-4 transition-colors">
            Admin Login
          </Link>
        </p>
      </div>
    </div>
  )
}
