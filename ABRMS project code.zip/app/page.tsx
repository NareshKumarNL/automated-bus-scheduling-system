import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, Bus, Calendar, Clock, MapPin, Users, BarChart3, Shield } from "lucide-react"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-slate-50 to-slate-100">
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center space-x-2">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-1.5 rounded-md">
              <Bus className="h-5 w-5 text-white" />
            </div>
            <span className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
              SmartTransit
            </span>
          </div>
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/login" className="text-sm font-medium text-slate-700 hover:text-blue-600 transition-colors">
              Login
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter text-white sm:text-5xl xl:text-6xl/none">
                    Smart Transit Management System
                  </h1>
                  <p className="max-w-[600px] text-white/90 md:text-xl">
                    Revolutionizing public transportation with intelligent scheduling and route optimization
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/login">
                    <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50">
                      Admin Login
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/crew-login">
                    <Button
                      size="lg"
                      variant="outline"
                      className="bg-transparent text-white border-white hover:bg-white/10"
                    >
                      Crew Login
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="relative w-full h-[300px] overflow-hidden rounded-xl shadow-2xl">
                  <Image
                    src="/placeholder.svg?height=600&width=800"
                    alt="Smart Transit Bus"
                    fill
                    className="object-cover"
                    priority
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 right-4 text-white">
                    <h3 className="text-xl font-bold">Next-Gen Transit Solutions</h3>
                    <p className="text-sm text-white/80">Connecting cities with intelligent transportation</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 bg-white">
          <div className="container px-4 md:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Intelligent Transit Management</h2>
              <p className="text-slate-600 max-w-2xl mx-auto">
                Our comprehensive system provides everything you need to manage modern transit operations
              </p>
            </div>
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
              <Card className="bg-white border-none shadow-lg hover:shadow-xl transition-shadow overflow-hidden group">
                <div className="h-2 bg-gradient-to-r from-blue-500 to-cyan-500"></div>
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4 group-hover:bg-blue-500 transition-colors">
                    <Users className="h-6 w-6 text-blue-600 group-hover:text-white transition-colors" />
                  </div>
                  <CardTitle className="text-slate-900">Crew Management</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">
                    Smart scheduling with AI-powered rest period compliance and assignment optimization
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-white border-none shadow-lg hover:shadow-xl transition-shadow overflow-hidden group">
                <div className="h-2 bg-gradient-to-r from-purple-500 to-pink-500"></div>
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-4 group-hover:bg-purple-500 transition-colors">
                    <Bus className="h-6 w-6 text-purple-600 group-hover:text-white transition-colors" />
                  </div>
                  <CardTitle className="text-slate-900">Fleet Management</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">
                    Real-time tracking and maintenance scheduling for optimal fleet performance
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-white border-none shadow-lg hover:shadow-xl transition-shadow overflow-hidden group">
                <div className="h-2 bg-gradient-to-r from-emerald-500 to-green-500"></div>
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center mb-4 group-hover:bg-emerald-500 transition-colors">
                    <MapPin className="h-6 w-6 text-emerald-600 group-hover:text-white transition-colors" />
                  </div>
                  <CardTitle className="text-slate-900">Route Optimization</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">
                    AI-powered route planning that reduces fuel consumption and travel time
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-white border-none shadow-lg hover:shadow-xl transition-shadow overflow-hidden group">
                <div className="h-2 bg-gradient-to-r from-orange-500 to-red-500"></div>
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center mb-4 group-hover:bg-orange-500 transition-colors">
                    <Shield className="h-6 w-6 text-orange-600 group-hover:text-white transition-colors" />
                  </div>
                  <CardTitle className="text-slate-900">Emergency Response</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">
                    Rapid incident management with automated alerts and resource allocation
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="mt-16 text-center">
              <Link href="/public/schedules">
                <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white">
                  <Calendar className="mr-2 h-4 w-4" />
                  Check Bus Schedules
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 bg-gradient-to-r from-slate-100 to-slate-200">
          <div className="container px-4 md:px-6">
            <div className="grid gap-10 lg:grid-cols-2 items-center">
              <div>
                <h2 className="text-3xl font-bold text-slate-900 mb-4">Data-Driven Transit Solutions</h2>
                <p className="text-slate-600 mb-6">
                  SmartTransit leverages real-time data analytics to optimize routes, reduce wait times, and improve the
                  overall passenger experience.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white p-4 rounded-lg shadow-md">
                    <h3 className="font-bold text-blue-600 text-2xl mb-2">1200+</h3>
                    <p className="text-slate-600">Buses Managed</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg shadow-md">
                    <h3 className="font-bold text-purple-600 text-2xl mb-2">2500+</h3>
                    <p className="text-slate-600">Crew Members</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg shadow-md">
                    <h3 className="font-bold text-emerald-600 text-2xl mb-2">150+</h3>
                    <p className="text-slate-600">Optimized Routes</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg shadow-md">
                    <h3 className="font-bold text-orange-600 text-2xl mb-2">5000+</h3>
                    <p className="text-slate-600">Daily Trips</p>
                  </div>
                </div>
              </div>
              <div className="relative h-[400px] rounded-xl overflow-hidden shadow-xl">
                <Image
                  src="/placeholder.svg?height=800&width=1200"
                  alt="Data analytics dashboard"
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <h3 className="text-xl font-bold">Real-time Analytics</h3>
                  <p className="text-sm text-white/80">Make data-driven decisions to improve service quality</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 bg-white">
          <div className="container px-4 md:px-6">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Why Choose SmartTransit?</h2>
              <p className="text-slate-600 max-w-2xl mx-auto">
                Our platform offers unparalleled features designed specifically for modern transit operations
              </p>
            </div>
            <div className="grid gap-8 md:grid-cols-3">
              <Card className="bg-white border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                    <BarChart3 className="h-6 w-6 text-blue-600" />
                  </div>
                  <CardTitle className="text-slate-900">Advanced Analytics</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">
                    Gain insights from comprehensive data analysis to optimize operations and reduce costs
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-white border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-4">
                    <Clock className="h-6 w-6 text-purple-600" />
                  </div>
                  <CardTitle className="text-slate-900">Real-time Monitoring</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">
                    Track your entire fleet in real-time with instant alerts for delays or incidents
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-white border-none shadow-lg hover:shadow-xl transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center mb-4">
                    <Shield className="h-6 w-6 text-emerald-600" />
                  </div>
                  <CardTitle className="text-slate-900">Enhanced Safety</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">
                    Improve passenger and crew safety with proactive monitoring and rapid response systems
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t py-6 md:py-0 bg-gradient-to-r from-blue-900 to-indigo-900 text-white">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <div className="flex items-center space-x-2">
            <div className="bg-white/10 p-1 rounded-md">
              <Bus className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-medium">SmartTransit</span>
          </div>
          <p className="text-center text-sm leading-loose md:text-left text-white/80">
            © 2023 SmartTransit. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}
