"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { useAppStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { format } from "date-fns"
import { ArrowLeft, Bus, Check, Download, Share2, Ticket } from "lucide-react"

export default function TicketConfirmationPage() {
  const searchParams = useSearchParams()
  const ticketId = searchParams.get("ticketId")

  const { tickets, schedules, routes, buses } = useAppStore()

  const [ticket, setTicket] = useState(null)
  const [schedule, setSchedule] = useState(null)
  const [route, setRoute] = useState(null)
  const [bus, setBus] = useState(null)

  useEffect(() => {
    if (ticketId) {
      const foundTicket = tickets.find((t) => t.id.toString() === ticketId)
      if (foundTicket) {
        setTicket(foundTicket)

        const foundSchedule = schedules.find((s) => s.id === foundTicket.scheduleId)
        if (foundSchedule) {
          setSchedule(foundSchedule)

          const foundRoute = routes.find((r) => r.routeNumber === foundSchedule.routeNumber)
          if (foundRoute) {
            setRoute(foundRoute)
          }

          const foundBus = buses.find((b) => b.busNumber === foundSchedule.busNumber)
          if (foundBus) {
            setBus(foundBus)
          }
        }
      }
    }
  }, [ticketId, tickets, schedules, routes, buses])

  if (!ticket || !schedule || !route || !bus) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-800">Loading ticket details...</h2>
          <p className="text-slate-600 mt-2">Please wait while we fetch your ticket information.</p>
        </div>
      </div>
    )
  }

  const formatDateTime = (dateTimeStr) => {
    const date = new Date(dateTimeStr)
    return format(date, "MMM dd, yyyy HH:mm")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center space-x-2">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-1.5 rounded-md">
              <Bus className="h-5 w-5 text-white" />
            </div>
            <span className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
              SmartTransit
            </span>
          </div>
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/" className="text-sm font-medium text-slate-700 hover:text-blue-600 transition-colors">
              Home
            </Link>
            <Link
              href="/public/schedules"
              className="text-sm font-medium text-slate-700 hover:text-blue-600 transition-colors"
            >
              Schedules
            </Link>
          </nav>
        </div>
      </header>

      <main className="container py-8 px-4 md:px-6">
        <div className="flex items-center mb-6">
          <Link href="/public/schedules">
            <Button variant="ghost" className="flex items-center gap-2 text-slate-700 hover:text-blue-600 p-0">
              <ArrowLeft className="h-4 w-4" />
              Back to Schedules
            </Button>
          </Link>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900 ml-4">Booking Confirmation</h1>
        </div>

        <div className="max-w-3xl mx-auto">
          <div className="mb-8 p-6 bg-green-50 rounded-lg border border-green-200 flex items-center justify-center">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-green-100 mb-4">
                <Check className="h-8 w-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-green-800 mb-2">Booking Confirmed!</h2>
              <p className="text-green-700">
                Your ticket has been booked successfully. Ticket ID: <span className="font-medium">{ticket.id}</span>
              </p>
            </div>
          </div>

          <Card className="border-none shadow-lg mb-8">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>E-Ticket</CardTitle>
                  <CardDescription className="text-blue-100">Show this ticket when boarding</CardDescription>
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="bg-white/20 text-white border-white/40 hover:bg-white/30"
                  >
                    <Download className="h-4 w-4 mr-1" />
                    Download
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="bg-white/20 text-white border-white/40 hover:bg-white/30"
                  >
                    <Share2 className="h-4 w-4 mr-1" />
                    Share
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex-1 space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Route</h3>
                    <p className="text-slate-900 font-medium">
                      Route {route.routeNumber}: {route.startPoint} - {route.endPoint}
                    </p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Bus Number</h3>
                    <p className="text-slate-900">
                      {bus.busNumber} ({bus.model})
                    </p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Departure Time</h3>
                    <p className="text-slate-900">{formatDateTime(schedule.departureTime)}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Journey Duration</h3>
                    <p className="text-slate-900">
                      {Math.floor(route.estimatedTime / 60)}h {route.estimatedTime % 60}m
                    </p>
                  </div>
                </div>

                <Separator orientation="vertical" className="hidden md:block" />

                <div className="flex-1 space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Passenger Name</h3>
                    <p className="text-slate-900">{ticket.passengerName}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Number of Passengers</h3>
                    <p className="text-slate-900">
                      {ticket.passengerCount} {ticket.passengerCount === 1 ? "person" : "people"}
                    </p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Seat Numbers</h3>
                    <div className="flex flex-wrap gap-1">
                      {ticket.seatNumbers.map((seat) => (
                        <span key={seat} className="px-2 py-0.5 bg-blue-100 text-blue-800 rounded text-xs">
                          Seat {seat}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Payment Method</h3>
                    <p className="text-slate-900 capitalize">{ticket.paymentMethod}</p>
                  </div>
                </div>
              </div>

              <div className="mt-8 p-4 bg-slate-50 rounded-lg border border-slate-200">
                <div className="flex flex-col md:flex-row justify-between items-center">
                  <div className="flex items-center gap-3 mb-4 md:mb-0">
                    <Ticket className="h-6 w-6 text-blue-600" />
                    <div>
                      <p className="font-medium text-slate-900">Ticket ID: {ticket.id}</p>
                      <p className="text-sm text-slate-600">Booked on {formatDateTime(ticket.bookingTime)}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-slate-600">Total Amount</p>
                    <p className="text-xl font-bold text-slate-900">₹{ticket.totalAmount.toFixed(2)}</p>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-slate-50 p-6 border-t border-slate-100 rounded-b-lg">
              <div className="w-full flex flex-col md:flex-row gap-4 justify-between items-center">
                <p className="text-sm text-slate-600 text-center md:text-left">
                  Please arrive at least 15 minutes before departure. Show this e-ticket when boarding.
                </p>
                <Link href="/">
                  <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white">
                    Return to Home
                  </Button>
                </Link>
              </div>
            </CardFooter>
          </Card>

          <div className="text-center">
            <h3 className="text-lg font-medium text-slate-900 mb-2">Need Help?</h3>
            <p className="text-slate-600 mb-4">
              If you have any questions or need assistance with your booking, please contact our customer support.
            </p>
            <div className="flex justify-center gap-4">
              <Button variant="outline" className="border-slate-200 text-slate-700 hover:bg-slate-50">
                Contact Support
              </Button>
              <Link href="/public/schedules">
                <Button variant="outline" className="border-slate-200 text-slate-700 hover:bg-slate-50">
                  Book Another Ticket
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t py-6 md:py-0 bg-gradient-to-r from-blue-900 to-indigo-900 text-white mt-12">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <div className="flex items-center space-x-2">
            <div className="bg-white/10 p-1 rounded-md">
              <Bus className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-medium">SmartTransit</span>
          </div>
          <p className="text-center text-sm leading-loose md:text-left text-white/80">
            © 2023 SmartTransit. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}
