"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { useAppStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { format } from "date-fns"
import { ArrowLeft, Bus, CreditCard, User } from "lucide-react"

export default function BookTicketPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const scheduleId = searchParams.get("scheduleId")

  const { schedules, routes, buses, bookTicket } = useAppStore()

  const [schedule, setSchedule] = useState(null)
  const [route, setRoute] = useState(null)
  const [bus, setBus] = useState(null)
  const [bookingDetails, setBookingDetails] = useState({
    passengerName: "",
    passengerPhone: "",
    passengerEmail: "",
    passengerCount: "1",
    paymentMethod: "card",
    seatNumbers: [],
  })
  const [availableSeats, setAvailableSeats] = useState([])
  const [selectedSeats, setSelectedSeats] = useState([])
  const [ticketPrice, setTicketPrice] = useState(0)

  useEffect(() => {
    if (scheduleId) {
      const foundSchedule = schedules.find((s) => s.id.toString() === scheduleId)
      if (foundSchedule) {
        setSchedule(foundSchedule)

        const foundRoute = routes.find((r) => r.routeNumber === foundSchedule.routeNumber)
        if (foundRoute) {
          setRoute(foundRoute)
          // Set ticket price based on route distance
          const basePrice = 50 // Base price in rupees
          const pricePerMinute = 0.5 // Additional price per minute of travel
          const calculatedPrice = basePrice + foundRoute.estimatedTime * pricePerMinute
          setTicketPrice(Math.round(calculatedPrice))
        }

        const foundBus = buses.find((b) => b.busNumber === foundSchedule.busNumber)
        if (foundBus) {
          setBus(foundBus)

          // Generate available seats
          const totalSeats = foundBus.capacity
          const bookedSeats = [] // In a real app, this would come from a database
          const available = Array.from({ length: totalSeats }, (_, i) => {
            const seatNumber = i + 1
            return {
              number: seatNumber,
              isAvailable: !bookedSeats.includes(seatNumber),
            }
          })
          setAvailableSeats(available)
        }
      }
    }
  }, [scheduleId, schedules, routes, buses])

  const handleSeatSelection = (seatNumber) => {
    if (selectedSeats.includes(seatNumber)) {
      setSelectedSeats(selectedSeats.filter((seat) => seat !== seatNumber))
    } else {
      if (selectedSeats.length < Number.parseInt(bookingDetails.passengerCount)) {
        setSelectedSeats([...selectedSeats, seatNumber])
      }
    }
  }

  const handlePassengerCountChange = (value) => {
    setBookingDetails({ ...bookingDetails, passengerCount: value })
    // Reset seat selection if passenger count is reduced
    if (Number.parseInt(value) < selectedSeats.length) {
      setSelectedSeats(selectedSeats.slice(0, Number.parseInt(value)))
    }
  }

  const handleBookTicket = () => {
    if (selectedSeats.length !== Number.parseInt(bookingDetails.passengerCount)) {
      alert("Please select seats for all passengers")
      return
    }

    const ticketData = {
      scheduleId: Number.parseInt(scheduleId),
      passengerName: bookingDetails.passengerName,
      passengerPhone: bookingDetails.passengerPhone,
      passengerEmail: bookingDetails.passengerEmail,
      passengerCount: Number.parseInt(bookingDetails.passengerCount),
      seatNumbers: selectedSeats,
      paymentMethod: bookingDetails.paymentMethod,
      totalAmount: ticketPrice * Number.parseInt(bookingDetails.passengerCount),
      bookingTime: new Date().toISOString(),
      status: "Confirmed",
    }

    const ticketId = bookTicket(ticketData)
    router.push(`/public/schedules/book/confirmation?ticketId=${ticketId}`)
  }

  if (!schedule || !route || !bus) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-slate-800">Loading booking details...</h2>
          <p className="text-slate-600 mt-2">Please wait while we fetch your booking information.</p>
        </div>
      </div>
    )
  }

  const formatDateTime = (dateTimeStr) => {
    const date = new Date(dateTimeStr)
    return format(date, "MMM dd, yyyy HH:mm")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center space-x-2">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-1.5 rounded-md">
              <Bus className="h-5 w-5 text-white" />
            </div>
            <span className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
              SmartTransit
            </span>
          </div>
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/" className="text-sm font-medium text-slate-700 hover:text-blue-600 transition-colors">
              Home
            </Link>
            <Link
              href="/public/schedules"
              className="text-sm font-medium text-slate-700 hover:text-blue-600 transition-colors"
            >
              Schedules
            </Link>
          </nav>
        </div>
      </header>

      <main className="container py-8 px-4 md:px-6">
        <div className="flex items-center mb-6">
          <Link href="/public/schedules">
            <Button variant="ghost" className="flex items-center gap-2 text-slate-700 hover:text-blue-600 p-0">
              <ArrowLeft className="h-4 w-4" />
              Back to Schedules
            </Button>
          </Link>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900 ml-4">Book Ticket</h1>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <Card className="border-none shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
                <CardTitle>Passenger Information</CardTitle>
                <CardDescription className="text-blue-100">
                  Please provide passenger details for your booking
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 pt-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="grid gap-2">
                    <Label htmlFor="passengerName" className="text-slate-700">
                      Full Name
                    </Label>
                    <div className="relative">
                      <User className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                      <Input
                        id="passengerName"
                        placeholder="Enter passenger name"
                        value={bookingDetails.passengerName}
                        onChange={(e) => setBookingDetails({ ...bookingDetails, passengerName: e.target.value })}
                        required
                        className="pl-9 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="passengerPhone" className="text-slate-700">
                      Phone Number
                    </Label>
                    <Input
                      id="passengerPhone"
                      placeholder="Enter phone number"
                      value={bookingDetails.passengerPhone}
                      onChange={(e) => setBookingDetails({ ...bookingDetails, passengerPhone: e.target.value })}
                      required
                      className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="passengerEmail" className="text-slate-700">
                    Email Address
                  </Label>
                  <Input
                    id="passengerEmail"
                    type="email"
                    placeholder="Enter email address"
                    value={bookingDetails.passengerEmail}
                    onChange={(e) => setBookingDetails({ ...bookingDetails, passengerEmail: e.target.value })}
                    required
                    className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="passengerCount" className="text-slate-700">
                    Number of Passengers
                  </Label>
                  <Select value={bookingDetails.passengerCount} onValueChange={handlePassengerCountChange}>
                    <SelectTrigger id="passengerCount" className="border-slate-200 focus:ring-blue-500">
                      <SelectValue placeholder="Select number of passengers" />
                    </SelectTrigger>
                    <SelectContent className="bg-white border-slate-200">
                      <SelectItem value="1">1 Passenger</SelectItem>
                      <SelectItem value="2">2 Passengers</SelectItem>
                      <SelectItem value="3">3 Passengers</SelectItem>
                      <SelectItem value="4">4 Passengers</SelectItem>
                      <SelectItem value="5">5 Passengers</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-t-lg">
                <CardTitle>Seat Selection</CardTitle>
                <CardDescription className="text-purple-100">
                  Select {bookingDetails.passengerCount} seat(s) for your journey
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="mb-4 p-4 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 bg-green-100 border border-green-300 rounded"></div>
                      <span className="text-sm text-slate-700">Available</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 bg-blue-500 rounded"></div>
                      <span className="text-sm text-slate-700">Selected</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 bg-slate-300 rounded"></div>
                      <span className="text-sm text-slate-700">Booked</span>
                    </div>
                  </div>
                </div>

                <div className="relative mb-8 p-4 bg-slate-100 rounded-lg border border-slate-200">
                  <div className="absolute top-2 left-1/2 transform -translate-x-1/2 text-center">
                    <div className="w-20 h-8 bg-slate-300 rounded-t-lg flex items-center justify-center">
                      <span className="text-xs font-medium text-slate-700">FRONT</span>
                    </div>
                  </div>

                  <div className="mt-10 grid grid-cols-5 gap-2 md:gap-4">
                    {availableSeats.map((seat) => (
                      <button
                        key={seat.number}
                        className={`
                          w-full aspect-square rounded-md flex items-center justify-center text-sm font-medium
                          ${
                            !seat.isAvailable
                              ? "bg-slate-300 cursor-not-allowed"
                              : selectedSeats.includes(seat.number)
                                ? "bg-blue-500 text-white"
                                : "bg-green-100 border border-green-300 hover:bg-green-200"
                          }
                        `}
                        onClick={() => seat.isAvailable && handleSeatSelection(seat.number)}
                        disabled={
                          !seat.isAvailable ||
                          (selectedSeats.length >= Number.parseInt(bookingDetails.passengerCount) &&
                            !selectedSeats.includes(seat.number))
                        }
                      >
                        {seat.number}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                  <h3 className="font-medium text-blue-800 mb-2">Selected Seats</h3>
                  {selectedSeats.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {selectedSeats.map((seat) => (
                        <div key={seat} className="px-3 py-1 bg-blue-500 text-white rounded-full text-sm">
                          Seat {seat}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-blue-700">
                      No seats selected yet. Please select {bookingDetails.passengerCount} seat(s).
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-t-lg">
                <CardTitle>Payment Method</CardTitle>
                <CardDescription className="text-emerald-100">Choose your preferred payment method</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <RadioGroup
                  value={bookingDetails.paymentMethod}
                  onValueChange={(value) => setBookingDetails({ ...bookingDetails, paymentMethod: value })}
                  className="space-y-3"
                >
                  <div className="flex items-center space-x-2 rounded-md border border-slate-200 p-4 hover:bg-slate-50">
                    <RadioGroupItem value="card" id="card" />
                    <Label htmlFor="card" className="flex-1 cursor-pointer">
                      <div className="flex items-center gap-3">
                        <CreditCard className="h-5 w-5 text-slate-600" />
                        <div>
                          <p className="font-medium text-slate-900">Credit/Debit Card</p>
                          <p className="text-sm text-slate-500">Pay securely with your card</p>
                        </div>
                      </div>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-md border border-slate-200 p-4 hover:bg-slate-50">
                    <RadioGroupItem value="upi" id="upi" />
                    <Label htmlFor="upi" className="flex-1 cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="h-5 w-5 rounded-full bg-green-500 flex items-center justify-center text-white text-xs font-bold">
                          U
                        </div>
                        <div>
                          <p className="font-medium text-slate-900">UPI</p>
                          <p className="text-sm text-slate-500">Pay using UPI apps</p>
                        </div>
                      </div>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-md border border-slate-200 p-4 hover:bg-slate-50">
                    <RadioGroupItem value="cash" id="cash" />
                    <Label htmlFor="cash" className="flex-1 cursor-pointer">
                      <div className="flex items-center gap-3">
                        <div className="h-5 w-5 rounded-full bg-orange-500 flex items-center justify-center text-white text-xs font-bold">
                          ₹
                        </div>
                        <div>
                          <p className="font-medium text-slate-900">Cash on Boarding</p>
                          <p className="text-sm text-slate-500">Pay cash when boarding the bus</p>
                        </div>
                      </div>
                    </Label>
                  </div>
                </RadioGroup>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="border-none shadow-lg sticky top-24">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
                <CardTitle>Booking Summary</CardTitle>
                <CardDescription className="text-blue-100">Review your booking details</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Route</h3>
                    <p className="text-slate-900 font-medium">
                      Route {route.routeNumber}: {route.startPoint} - {route.endPoint}
                    </p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Bus Number</h3>
                    <p className="text-slate-900">
                      {bus.busNumber} ({bus.model})
                    </p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Departure Time</h3>
                    <p className="text-slate-900">{formatDateTime(schedule.departureTime)}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Journey Duration</h3>
                    <p className="text-slate-900">
                      {Math.floor(route.estimatedTime / 60)}h {route.estimatedTime % 60}m
                    </p>
                  </div>

                  <Separator className="my-4" />

                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Passengers</h3>
                    <p className="text-slate-900">
                      {bookingDetails.passengerCount}{" "}
                      {Number.parseInt(bookingDetails.passengerCount) === 1 ? "person" : "people"}
                    </p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Selected Seats</h3>
                    {selectedSeats.length > 0 ? (
                      <div className="flex flex-wrap gap-1">
                        {selectedSeats.map((seat) => (
                          <span key={seat} className="px-2 py-0.5 bg-blue-100 text-blue-800 rounded text-xs">
                            Seat {seat}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-slate-600 text-sm">No seats selected</p>
                    )}
                  </div>

                  <Separator className="my-4" />

                  <div className="flex justify-between items-center">
                    <span className="text-slate-700">Ticket Price</span>
                    <span className="text-slate-900">
                      ₹{ticketPrice.toFixed(2)} × {bookingDetails.passengerCount}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-700">Service Fee</span>
                    <span className="text-slate-900">₹20.00</span>
                  </div>
                  <div className="flex justify-between items-center font-medium text-lg pt-2">
                    <span className="text-slate-900">Total</span>
                    <span className="text-slate-900">
                      ₹{(ticketPrice * Number.parseInt(bookingDetails.passengerCount) + 20).toFixed(2)}
                    </span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col gap-4">
                <Button
                  onClick={handleBookTicket}
                  disabled={
                    !bookingDetails.passengerName ||
                    !bookingDetails.passengerPhone ||
                    selectedSeats.length !== Number.parseInt(bookingDetails.passengerCount)
                  }
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
                >
                  Confirm & Pay
                </Button>
                <p className="text-xs text-center text-slate-500">
                  By clicking "Confirm & Pay", you agree to our Terms of Service and Privacy Policy.
                </p>
              </CardFooter>
            </Card>
          </div>
        </div>
      </main>

      <footer className="border-t py-6 md:py-0 bg-gradient-to-r from-blue-900 to-indigo-900 text-white mt-12">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <div className="flex items-center space-x-2">
            <div className="bg-white/10 p-1 rounded-md">
              <Bus className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-medium">SmartTransit</span>
          </div>
          <p className="text-center text-sm leading-loose md:text-left text-white/80">
            © 2023 SmartTransit. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}
