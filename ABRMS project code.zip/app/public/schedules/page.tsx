"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useAppStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { format } from "date-fns"
import { Bus, ArrowLeft, Search, Calendar, Clock, MapPin } from "lucide-react"

export default function PublicSchedulesPage() {
  const router = useRouter()
  const { routes, schedules } = useAppStore()
  const [userDetails, setUserDetails] = useState({
    name: "",
    phone: "",
    email: "",
  })
  const [searchParams, setSearchParams] = useState({
    from: "",
    to: "",
    date: "",
  })
  const [showSchedules, setShowSchedules] = useState(false)
  const [filteredSchedules, setFilteredSchedules] = useState([])

  const handleSubmit = (e) => {
    e.preventDefault()

    // Filter schedules based on search parameters
    const filtered = schedules.filter((schedule) => {
      const route = routes.find((r) => r.routeNumber === schedule.routeNumber)
      if (!route) return false

      const matchesRoute =
        (searchParams.from === "" ||
          route.startPoint.toLowerCase().includes(searchParams.from.toLowerCase()) ||
          route.endPoint.toLowerCase().includes(searchParams.from.toLowerCase())) &&
        (searchParams.to === "" ||
          route.startPoint.toLowerCase().includes(searchParams.to.toLowerCase()) ||
          route.endPoint.toLowerCase().includes(searchParams.to.toLowerCase()))

      // If date is provided, check if schedule matches the date
      let matchesDate = true
      if (searchParams.date) {
        const scheduleDate = new Date(schedule.departureTime)
        const searchDate = new Date(searchParams.date)
        matchesDate =
          scheduleDate.getDate() === searchDate.getDate() &&
          scheduleDate.getMonth() === searchDate.getMonth() &&
          scheduleDate.getFullYear() === searchDate.getFullYear()
      }

      return matchesRoute && matchesDate
    })

    setFilteredSchedules(filtered)
    setShowSchedules(true)
  }

  const formatDateTime = (dateTimeStr) => {
    const date = new Date(dateTimeStr)
    return format(date, "MMM dd, yyyy HH:mm")
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "Scheduled":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Scheduled
          </Badge>
        )
      case "In Progress":
        return (
          <Badge variant="secondary" className="bg-purple-50 text-purple-700 border-purple-200">
            In Progress
          </Badge>
        )
      case "Completed":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Completed
          </Badge>
        )
      case "Cancelled":
        return (
          <Badge variant="destructive" className="bg-red-50 text-red-700 border-red-200">
            Cancelled
          </Badge>
        )
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center">
          <div className="flex items-center space-x-2">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-1.5 rounded-md">
              <Bus className="h-5 w-5 text-white" />
            </div>
            <span className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
              SmartTransit
            </span>
          </div>
          <nav className="ml-auto flex gap-4 sm:gap-6">
            <Link href="/" className="text-sm font-medium text-slate-700 hover:text-blue-600 transition-colors">
              Home
            </Link>
            <Link href="/login" className="text-sm font-medium text-slate-700 hover:text-blue-600 transition-colors">
              Login
            </Link>
          </nav>
        </div>
      </header>

      <main className="container py-8 px-4 md:px-6">
        <div className="flex items-center mb-6">
          <Link href="/">
            <Button variant="ghost" className="flex items-center gap-2 text-slate-700 hover:text-blue-600 p-0">
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Button>
          </Link>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900 ml-4">Bus Schedules</h1>
        </div>

        {!showSchedules ? (
          <div className="grid gap-8 md:grid-cols-2">
            <Card className="border-none shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
                <CardTitle>Your Details</CardTitle>
                <CardDescription className="text-blue-100">
                  Please provide your information to check schedules
                </CardDescription>
              </CardHeader>
              <form onSubmit={handleSubmit}>
                <CardContent className="space-y-4 pt-6">
                  <div className="grid gap-2">
                    <Label htmlFor="name" className="text-slate-700">
                      Full Name
                    </Label>
                    <Input
                      id="name"
                      placeholder="Enter your full name"
                      value={userDetails.name}
                      onChange={(e) => setUserDetails({ ...userDetails, name: e.target.value })}
                      required
                      className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="phone" className="text-slate-700">
                      Phone Number
                    </Label>
                    <Input
                      id="phone"
                      placeholder="Enter your phone number"
                      value={userDetails.phone}
                      onChange={(e) => setUserDetails({ ...userDetails, phone: e.target.value })}
                      required
                      className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="email" className="text-slate-700">
                      Email Address
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter your email address"
                      value={userDetails.email}
                      onChange={(e) => setUserDetails({ ...userDetails, email: e.target.value })}
                      required
                      className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between border-t border-slate-100 p-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => router.push("/")}
                    className="border-slate-200 text-slate-700 hover:bg-slate-50"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
                  >
                    Continue
                  </Button>
                </CardFooter>
              </form>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
                <CardTitle>Search Schedules</CardTitle>
                <CardDescription className="text-blue-100">Find bus schedules for your journey</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 pt-6">
                <div className="grid gap-2">
                  <Label htmlFor="from" className="text-slate-700">
                    From
                  </Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <Input
                      id="from"
                      placeholder="Departure city"
                      value={searchParams.from}
                      onChange={(e) => setSearchParams({ ...searchParams, from: e.target.value })}
                      className="pl-9 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="to" className="text-slate-700">
                    To
                  </Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <Input
                      id="to"
                      placeholder="Destination city"
                      value={searchParams.to}
                      onChange={(e) => setSearchParams({ ...searchParams, to: e.target.value })}
                      className="pl-9 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="date" className="text-slate-700">
                    Date of Travel
                  </Label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <Input
                      id="date"
                      type="date"
                      value={searchParams.date}
                      onChange={(e) => setSearchParams({ ...searchParams, date: e.target.value })}
                      className="pl-9 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="space-y-6">
            <Card className="border-none shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Available Schedules</CardTitle>
                    <CardDescription className="text-blue-100">
                      Showing schedules matching your search criteria
                    </CardDescription>
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => setShowSchedules(false)}
                    className="bg-white/20 text-white border-white/40 hover:bg-white/30"
                  >
                    Modify Search
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="mb-4 p-4 bg-blue-50 rounded-lg border border-blue-100">
                  <h3 className="font-medium text-blue-800 mb-1">Search Results</h3>
                  <p className="text-sm text-blue-700">
                    {filteredSchedules.length} schedules found
                    {searchParams.from && ` from "${searchParams.from}"`}
                    {searchParams.to && ` to "${searchParams.to}"`}
                    {searchParams.date && ` on ${new Date(searchParams.date).toLocaleDateString()}`}
                  </p>
                </div>

                <Tabs defaultValue="all" className="space-y-4">
                  <TabsList className="bg-slate-100 p-1">
                    <TabsTrigger value="all" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
                      All Schedules
                    </TabsTrigger>
                    <TabsTrigger
                      value="today"
                      className="data-[state=active]:bg-blue-600 data-[state=active]:text-white"
                    >
                      Today
                    </TabsTrigger>
                    <TabsTrigger
                      value="tomorrow"
                      className="data-[state=active]:bg-blue-600 data-[state=active]:text-white"
                    >
                      Tomorrow
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="all" className="space-y-4">
                    {filteredSchedules.length > 0 ? (
                      <div className="rounded-md border border-slate-200 overflow-hidden">
                        <Table>
                          <TableHeader className="bg-slate-50">
                            <TableRow className="hover:bg-slate-100/50">
                              <TableHead className="text-slate-700">Route</TableHead>
                              <TableHead className="text-slate-700">From - To</TableHead>
                              <TableHead className="text-slate-700">Departure</TableHead>
                              <TableHead className="text-slate-700">Status</TableHead>
                              <TableHead className="text-right text-slate-700">Action</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {filteredSchedules.map((schedule) => {
                              const route = routes.find((r) => r.routeNumber === schedule.routeNumber)
                              return (
                                <TableRow key={schedule.id} className="hover:bg-slate-50">
                                  <TableCell className="font-medium text-slate-800">
                                    Route {schedule.routeNumber}
                                  </TableCell>
                                  <TableCell className="text-slate-700">
                                    {route ? `${route.startPoint} - ${route.endPoint}` : "N/A"}
                                  </TableCell>
                                  <TableCell className="text-slate-700">
                                    {formatDateTime(schedule.departureTime)}
                                  </TableCell>
                                  <TableCell>{getStatusBadge(schedule.status)}</TableCell>
                                  <TableCell className="text-right">
                                    <Link href={`/public/schedules/book?scheduleId=${schedule.id}`}>
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        className="border-blue-200 text-blue-700 hover:bg-blue-50"
                                      >
                                        Book Ticket
                                      </Button>
                                    </Link>
                                  </TableCell>
                                </TableRow>
                              )
                            })}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-12 text-center">
                        <Search className="h-12 w-12 text-slate-300 mb-4" />
                        <h3 className="text-xl font-medium text-slate-900 mb-2">No schedules found</h3>
                        <p className="text-slate-600 max-w-md">
                          We couldn't find any schedules matching your search criteria. Please try different search
                          parameters.
                        </p>
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="today" className="space-y-4">
                    {filteredSchedules.filter((schedule) => {
                      const scheduleDate = new Date(schedule.departureTime)
                      const today = new Date()
                      return (
                        scheduleDate.getDate() === today.getDate() &&
                        scheduleDate.getMonth() === today.getMonth() &&
                        scheduleDate.getFullYear() === today.getFullYear()
                      )
                    }).length > 0 ? (
                      <div className="rounded-md border border-slate-200 overflow-hidden">
                        <Table>
                          <TableHeader className="bg-slate-50">
                            <TableRow className="hover:bg-slate-100/50">
                              <TableHead className="text-slate-700">Route</TableHead>
                              <TableHead className="text-slate-700">From - To</TableHead>
                              <TableHead className="text-slate-700">Departure</TableHead>
                              <TableHead className="text-slate-700">Status</TableHead>
                              <TableHead className="text-right text-slate-700">Action</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {filteredSchedules
                              .filter((schedule) => {
                                const scheduleDate = new Date(schedule.departureTime)
                                const today = new Date()
                                return (
                                  scheduleDate.getDate() === today.getDate() &&
                                  scheduleDate.getMonth() === today.getMonth() &&
                                  scheduleDate.getFullYear() === today.getFullYear()
                                )
                              })
                              .map((schedule) => {
                                const route = routes.find((r) => r.routeNumber === schedule.routeNumber)
                                return (
                                  <TableRow key={schedule.id} className="hover:bg-slate-50">
                                    <TableCell className="font-medium text-slate-800">
                                      Route {schedule.routeNumber}
                                    </TableCell>
                                    <TableCell className="text-slate-700">
                                      {route ? `${route.startPoint} - ${route.endPoint}` : "N/A"}
                                    </TableCell>
                                    <TableCell className="text-slate-700">
                                      {formatDateTime(schedule.departureTime)}
                                    </TableCell>
                                    <TableCell>{getStatusBadge(schedule.status)}</TableCell>
                                    <TableCell className="text-right">
                                      <Link href={`/public/schedules/book?scheduleId=${schedule.id}`}>
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          className="border-blue-200 text-blue-700 hover:bg-blue-50"
                                        >
                                          Book Ticket
                                        </Button>
                                      </Link>
                                    </TableCell>
                                  </TableRow>
                                )
                              })}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-12 text-center">
                        <Clock className="h-12 w-12 text-slate-300 mb-4" />
                        <h3 className="text-xl font-medium text-slate-900 mb-2">No schedules for today</h3>
                        <p className="text-slate-600 max-w-md">
                          We couldn't find any schedules for today matching your search criteria.
                        </p>
                      </div>
                    )}
                  </TabsContent>

                  <TabsContent value="tomorrow" className="space-y-4">
                    {filteredSchedules.filter((schedule) => {
                      const scheduleDate = new Date(schedule.departureTime)
                      const tomorrow = new Date()
                      tomorrow.setDate(tomorrow.getDate() + 1)
                      return (
                        scheduleDate.getDate() === tomorrow.getDate() &&
                        scheduleDate.getMonth() === tomorrow.getMonth() &&
                        scheduleDate.getFullYear() === tomorrow.getFullYear()
                      )
                    }).length > 0 ? (
                      <div className="rounded-md border border-slate-200 overflow-hidden">
                        <Table>
                          <TableHeader className="bg-slate-50">
                            <TableRow className="hover:bg-slate-100/50">
                              <TableHead className="text-slate-700">Route</TableHead>
                              <TableHead className="text-slate-700">From - To</TableHead>
                              <TableHead className="text-slate-700">Departure</TableHead>
                              <TableHead className="text-slate-700">Status</TableHead>
                              <TableHead className="text-right text-slate-700">Action</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {filteredSchedules
                              .filter((schedule) => {
                                const scheduleDate = new Date(schedule.departureTime)
                                const tomorrow = new Date()
                                tomorrow.setDate(tomorrow.getDate() + 1)
                                return (
                                  scheduleDate.getDate() === tomorrow.getDate() &&
                                  scheduleDate.getMonth() === tomorrow.getMonth() &&
                                  scheduleDate.getFullYear() === tomorrow.getFullYear()
                                )
                              })
                              .map((schedule) => {
                                const route = routes.find((r) => r.routeNumber === schedule.routeNumber)
                                return (
                                  <TableRow key={schedule.id} className="hover:bg-slate-50">
                                    <TableCell className="font-medium text-slate-800">
                                      Route {schedule.routeNumber}
                                    </TableCell>
                                    <TableCell className="text-slate-700">
                                      {route ? `${route.startPoint} - ${route.endPoint}` : "N/A"}
                                    </TableCell>
                                    <TableCell className="text-slate-700">
                                      {formatDateTime(schedule.departureTime)}
                                    </TableCell>
                                    <TableCell>{getStatusBadge(schedule.status)}</TableCell>
                                    <TableCell className="text-right">
                                      <Link href={`/public/schedules/book?scheduleId=${schedule.id}`}>
                                        <Button
                                          variant="outline"
                                          size="sm"
                                          className="border-blue-200 text-blue-700 hover:bg-blue-50"
                                        >
                                          Book Ticket
                                        </Button>
                                      </Link>
                                    </TableCell>
                                  </TableRow>
                                )
                              })}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-12 text-center">
                        <Calendar className="h-12 w-12 text-slate-300 mb-4" />
                        <h3 className="text-xl font-medium text-slate-900 mb-2">No schedules for tomorrow</h3>
                        <p className="text-slate-600 max-w-md">
                          We couldn't find any schedules for tomorrow matching your search criteria.
                        </p>
                      </div>
                    )}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardHeader className="bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-t-lg">
                <CardTitle>Your Information</CardTitle>
                <CardDescription className="text-green-100">
                  We'll use this information to contact you about your booking
                </CardDescription>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid gap-6 md:grid-cols-3">
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Full Name</h3>
                    <p className="text-slate-900">{userDetails.name}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Phone Number</h3>
                    <p className="text-slate-900">{userDetails.phone}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-slate-500 mb-1">Email Address</h3>
                    <p className="text-slate-900">{userDetails.email}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </main>

      <footer className="border-t py-6 md:py-0 bg-gradient-to-r from-blue-900 to-indigo-900 text-white">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
          <div className="flex items-center space-x-2">
            <div className="bg-white/10 p-1 rounded-md">
              <Bus className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-medium">SmartTransit</span>
          </div>
          <p className="text-center text-sm leading-loose md:text-left text-white/80">
            © 2023 SmartTransit. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}
