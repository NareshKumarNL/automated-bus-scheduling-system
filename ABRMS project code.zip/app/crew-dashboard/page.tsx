"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useAppStore } from "@/lib/store"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Clock, MapPin, AlertTriangle, Bus, User, Calendar, CheckCircle, XCircle, Clock4 } from "lucide-react"
import { format, parseISO, isToday, addDays } from "date-fns"

export default function CrewDashboardPage() {
  const { crews, schedules, routes, buses, selectedCrewId, setSelectedCrewId, checkInCrew, checkOutCrew } =
    useAppStore()
  const [crewAssignments, setCrewAssignments] = useState([])
  const [isCheckedIn, setIsCheckedIn] = useState(false)
  const [checkInTime, setCheckInTime] = useState(null)
  const [dutyHours, setDutyHours] = useState(0)
  const [dutyHoursInterval, setDutyHoursInterval] = useState(null)

  // Find crew member details based on selected ID
  const selectedCrew = selectedCrewId ? crews.find((crew) => crew.id === selectedCrewId) : null

  useEffect(() => {
    if (selectedCrew) {
      // Find all schedules assigned to this crew member
      const assignments = schedules
        .filter((schedule) => schedule.driver === selectedCrew.name || schedule.conductor === selectedCrew.name)
        .map((schedule) => {
          const route = routes.find((r) => r.routeNumber === schedule.routeNumber)
          const bus = buses.find((b) => b.busNumber === schedule.busNumber)
          return {
            ...schedule,
            routeDetails: route ? `${route.startPoint} - ${route.endPoint}` : "Unknown Route",
            routeInfo: route,
            busInfo: bus,
            role: schedule.driver === selectedCrew.name ? "Driver" : "Conductor",
          }
        })
        .sort((a, b) => new Date(a.departureTime).getTime() - new Date(b.departureTime).getTime())

      setCrewAssignments(assignments)

      // Check if crew is checked in
      setIsCheckedIn(selectedCrew.isCheckedIn || false)
      setCheckInTime(selectedCrew.checkInTime || null)

      // Calculate duty hours if checked in
      if (selectedCrew.isCheckedIn && selectedCrew.checkInTime) {
        calculateDutyHours(selectedCrew.checkInTime)

        // Set up interval to update duty hours every minute
        const interval = setInterval(() => {
          calculateDutyHours(selectedCrew.checkInTime)
        }, 60000) // Update every minute

        setDutyHoursInterval(interval)
      } else {
        setDutyHours(0)

        // Clear interval if exists
        if (dutyHoursInterval) {
          clearInterval(dutyHoursInterval)
          setDutyHoursInterval(null)
        }
      }
    }
  }, [selectedCrew, schedules, routes, buses])

  const formatDateTime = (dateTimeStr) => {
    if (!dateTimeStr) return "Not assigned yet"
    try {
      const date = parseISO(dateTimeStr)
      return format(date, "MMM dd, yyyy HH:mm")
    } catch (e) {
      return dateTimeStr
    }
  }

  const handleCheckIn = () => {
    if (isCheckedIn) {
      checkOutCrew(selectedCrewId)
      setIsCheckedIn(false)
      setCheckInTime(null)
      setDutyHours(0)
    } else {
      const now = new Date().toISOString()
      checkInCrew(selectedCrewId, now)
      setIsCheckedIn(true)
      setCheckInTime(now)
    }
  }

  const getTodayAssignments = () => {
    return crewAssignments.filter((assignment) => {
      try {
        const date = parseISO(assignment.departureTime)
        return isToday(date)
      } catch (e) {
        return false
      }
    })
  }

  const getUpcomingAssignments = () => {
    return crewAssignments
      .filter((assignment) => {
        try {
          const date = parseISO(assignment.departureTime)
          return date > new Date() && !isToday(date)
        } catch (e) {
          return false
        }
      })
      .slice(0, 3) // Get next 3 upcoming assignments
  }

  const getCurrentAssignment = () => {
    const inProgressAssignment = crewAssignments.find((a) => a.status === "In Progress")
    if (inProgressAssignment) return inProgressAssignment

    // If no in-progress assignment, get the next scheduled assignment for today
    const todayAssignments = getTodayAssignments()
    return todayAssignments.find((a) => a.status === "Scheduled") || null
  }

  const currentAssignment = getCurrentAssignment()

  return (
    <div className="flex min-h-screen flex-col bg-slate-50">
      <header className="sticky top-0 z-50 w-full border-b bg-white shadow-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="bg-gradient-to-r from-purple-600 to-blue-600 p-1.5 rounded-md">
              <Bus className="h-5 w-5 text-white" />
            </div>
            <span className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-blue-600">
              SmartTransit Crew
            </span>
          </div>
          <div className="flex items-center gap-4">
            {selectedCrew && (
              <div className="hidden md:flex items-center gap-2 bg-purple-50 px-3 py-1.5 rounded-full">
                <div className="w-6 h-6 rounded-full bg-purple-200 flex items-center justify-center">
                  <User className="h-3 w-3 text-purple-700" />
                </div>
                <span className="text-sm font-medium text-purple-700">{selectedCrew.name}</span>
              </div>
            )}
            <Link href="/">
              <Button variant="outline" className="border-slate-200 text-slate-700 hover:bg-slate-50">
                Logout
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 p-4 pt-6 md:p-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-slate-900">Crew Dashboard</h2>
            <p className="text-slate-600">Welcome back, {selectedCrew ? selectedCrew.name : "Crew Member"}</p>
          </div>
          {selectedCrew && (
            <div className="flex items-center gap-2">
              <Button
                onClick={handleCheckIn}
                className={
                  isCheckedIn
                    ? "bg-red-600 hover:bg-red-700 text-white"
                    : "bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
                }
              >
                {isCheckedIn ? (
                  <>
                    <XCircle className="mr-2 h-4 w-4" />
                    Check Out
                  </>
                ) : (
                  <>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Check In
                  </>
                )}
              </Button>
            </div>
          )}
        </div>

        <Card className="border-none shadow-md mb-6">
          <CardHeader className="bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-t-lg">
            <CardTitle>Select Your Crew ID</CardTitle>
            <CardDescription className="text-purple-100">
              Please select your crew ID to view your assignments and schedule
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4 items-center">
              <div className="w-full md:w-1/2">
                <Select
                  value={selectedCrewId ? selectedCrewId.toString() : ""}
                  onValueChange={(value) => setSelectedCrewId(Number.parseInt(value))}
                >
                  <SelectTrigger className="border-slate-200 focus:ring-purple-500">
                    <SelectValue placeholder="Select your crew ID" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    {crews.map((crew) => (
                      <SelectItem key={crew.id} value={crew.id.toString()}>
                        {crew.employeeId} - {crew.name} ({crew.role})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {selectedCrew && (
                <div className="bg-purple-50 p-4 rounded-lg border border-purple-100 w-full md:w-1/2">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                      <User className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-slate-900">{selectedCrew.name}</h3>
                      <div className="flex flex-wrap gap-2 mt-1">
                        <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                          ID: {selectedCrew.employeeId}
                        </Badge>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                          {selectedCrew.role}
                        </Badge>
                        <Badge
                          variant="outline"
                          className={
                            selectedCrew.isAvailable
                              ? "bg-green-50 text-green-700 border-green-200"
                              : "bg-amber-50 text-amber-700 border-amber-200"
                          }
                        >
                          {selectedCrew.isAvailable ? "Available" : "On Duty"}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {!selectedCrew ? (
          <div className="flex flex-col items-center justify-center p-12 bg-white rounded-lg shadow-md">
            <User className="h-16 w-16 text-slate-300 mb-4" />
            <h3 className="text-xl font-medium text-slate-900 mb-2">Please Select Your Crew ID</h3>
            <p className="text-slate-600 text-center max-w-md">
              Select your crew ID from the dropdown above to view your assignments, schedule, and other details.
            </p>
          </div>
        ) : (
          <>
            {isCheckedIn && (
              <Card className="border-none shadow-md mb-6 overflow-hidden">
                <div className="bg-gradient-to-r from-green-600 to-emerald-600 p-6 text-white">
                  <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                    <div>
                      <h3 className="text-xl font-bold">You're Checked In</h3>
                      <p className="text-green-100">
                        Checked in at {checkInTime ? format(parseISO(checkInTime), "hh:mm a") : "N/A"}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex flex-col items-center">
                        <span className="text-sm text-green-100">Duty Hours</span>
                        <span className="text-2xl font-bold">{dutyHours}</span>
                      </div>
                      <div className="h-10 w-px bg-green-400"></div>
                      <div className="flex flex-col items-center">
                        <span className="text-sm text-green-100">Status</span>
                        <span className="text-lg font-medium">Active</span>
                      </div>
                    </div>
                  </div>
                  <div className="mt-4">
                    <div className="flex justify-between text-xs mb-1">
                      <span>Shift Progress</span>
                      <span>{Math.min(Math.round((dutyHours / 8) * 100), 100)}%</span>
                    </div>
                    <Progress value={Math.min((dutyHours / 8) * 100, 100)} className="h-2 bg-green-200" />
                  </div>
                </div>
              </Card>
            )}

            <Tabs defaultValue="today" className="space-y-6">
              <TabsList className="bg-slate-100 p-1">
                <TabsTrigger value="today" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
                  Today's Schedule
                </TabsTrigger>
                <TabsTrigger
                  value="upcoming"
                  className="data-[state=active]:bg-blue-600 data-[state=active]:text-white"
                >
                  Upcoming Assignments
                </TabsTrigger>
                <TabsTrigger value="weekly" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
                  Weekly View
                </TabsTrigger>
              </TabsList>

              <TabsContent value="today" className="space-y-6">
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                  <Card className="border-none shadow-md">
                    <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
                      <CardTitle>Current Assignment</CardTitle>
                      <CardDescription className="text-blue-100">Your active duty details</CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                      {currentAssignment ? (
                        <div className="space-y-4">
                          <div className="flex justify-between items-center">
                            <span className="text-slate-600">Route:</span>
                            <span className="font-medium text-slate-900">
                              Route {currentAssignment.routeNumber} ({currentAssignment.routeDetails})
                            </span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-slate-600">Bus:</span>
                            <span className="font-medium text-slate-900">{currentAssignment.busNumber}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-slate-600">Role:</span>
                            <span className="font-medium text-slate-900">{currentAssignment.role}</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-slate-600">Departure:</span>
                            <span className="font-medium text-slate-900">
                              {formatDateTime(currentAssignment.departureTime)}
                            </span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-slate-600">Status:</span>
                            <Badge
                              className={
                                currentAssignment.status === "In Progress"
                                  ? "bg-green-100 text-green-800 border-green-200"
                                  : "bg-blue-100 text-blue-800 border-blue-200"
                              }
                            >
                              {currentAssignment.status === "In Progress" ? "On Duty" : "Scheduled"}
                            </Badge>
                          </div>

                          {currentAssignment.routeInfo && (
                            <div className="pt-2">
                              <div className="text-sm text-slate-500 mb-1">Journey Details</div>
                              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                                <div className="flex justify-between text-sm">
                                  <span className="text-slate-600">Duration:</span>
                                  <span className="text-slate-900">
                                    {Math.floor(currentAssignment.routeInfo.estimatedTime / 60)}h{" "}
                                    {currentAssignment.routeInfo.estimatedTime % 60}m
                                  </span>
                                </div>
                                <div className="flex justify-between text-sm mt-1">
                                  <span className="text-slate-600">Stops:</span>
                                  <span className="text-slate-900">{currentAssignment.routeInfo.stops}</span>
                                </div>
                              </div>
                            </div>
                          )}

                          <div className="pt-4">
                            <Button className="w-full bg-blue-50 text-blue-700 hover:bg-blue-100">
                              <MapPin className="mr-2 h-4 w-4" />
                              View Route Details
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center py-8 text-center">
                          <Clock className="h-12 w-12 text-slate-300 mb-4" />
                          <h3 className="text-lg font-medium text-slate-900 mb-2">No Active Assignment</h3>
                          <p className="text-slate-600">You don't have any active assignments for today.</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  <Card className="border-none shadow-md">
                    <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-t-lg">
                      <CardTitle>Today's Schedule</CardTitle>
                      <CardDescription className="text-purple-100">All assignments for today</CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {getTodayAssignments().length > 0 ? (
                          getTodayAssignments().map((assignment) => (
                            <div key={assignment.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                              <div className="flex justify-between items-center mb-2">
                                <span className="font-medium text-slate-900">Route {assignment.routeNumber}</span>
                                <Badge
                                  className={
                                    assignment.status === "Completed"
                                      ? "bg-green-100 text-green-800 border-green-200"
                                      : assignment.status === "In Progress"
                                        ? "bg-purple-100 text-purple-800 border-purple-200"
                                        : "bg-blue-100 text-blue-800 border-blue-200"
                                  }
                                >
                                  {assignment.status}
                                </Badge>
                              </div>
                              <div className="text-sm text-slate-600">
                                <div className="flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  <span>{formatDateTime(assignment.departureTime)}</span>
                                </div>
                                <div className="flex items-center gap-1 mt-1">
                                  <Bus className="h-3 w-3" />
                                  <span>{assignment.busNumber}</span>
                                </div>
                                <div className="flex items-center gap-1 mt-1">
                                  <MapPin className="h-3 w-3" />
                                  <span>{assignment.routeDetails}</span>
                                </div>
                              </div>
                            </div>
                          ))
                        ) : (
                          <div className="flex flex-col items-center justify-center py-8 text-center">
                            <Calendar className="h-12 w-12 text-slate-300 mb-4" />
                            <h3 className="text-lg font-medium text-slate-900 mb-2">No Assignments Today</h3>
                            <p className="text-slate-600">You don't have any assignments scheduled for today.</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="border-none shadow-md">
                    <CardHeader className="bg-gradient-to-r from-orange-600 to-red-600 text-white rounded-t-lg">
                      <CardTitle>Alerts & Notifications</CardTitle>
                      <CardDescription className="text-orange-100">Important updates</CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        <div className="flex items-start gap-3 p-3 bg-orange-50 rounded-lg border border-orange-200">
                          <AlertTriangle className="h-5 w-5 text-orange-600 mt-0.5" />
                          <div>
                            <h4 className="font-medium text-orange-800">Route Diversion</h4>
                            <p className="text-sm text-orange-700">
                              Route 107 diverted due to road construction in Madurai
                            </p>
                          </div>
                        </div>

                        <div className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                          <Clock className="h-5 w-5 text-blue-600 mt-0.5" />
                          <div>
                            <h4 className="font-medium text-blue-800">Schedule Update</h4>
                            <p className="text-sm text-blue-700">
                              Your shift on Friday has been rescheduled to 9:00 AM
                            </p>
                          </div>
                        </div>

                        {isCheckedIn && (
                          <div className="flex items-start gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                            <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                            <div>
                              <h4 className="font-medium text-green-800">Check-In Successful</h4>
                              <p className="text-sm text-green-700">
                                You checked in at {checkInTime ? format(parseISO(checkInTime), "hh:mm a") : "N/A"}
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="upcoming" className="space-y-6">
                <Card className="border-none shadow-md">
                  <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
                    <CardTitle>Upcoming Assignments</CardTitle>
                    <CardDescription className="text-blue-100">Your scheduled duties for the next days</CardDescription>
                  </CardHeader>
                  <CardContent className="p-6">
                    {getUpcomingAssignments().length > 0 ? (
                      <div className="space-y-6">
                        {getUpcomingAssignments().map((assignment, index) => (
                          <div key={assignment.id} className="flex flex-col md:flex-row gap-4 items-start">
                            <div className="flex-shrink-0 w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center">
                              <Calendar className="h-8 w-8 text-blue-600" />
                            </div>
                            <div className="flex-1">
                              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                                <h3 className="text-lg font-medium text-slate-900">
                                  Route {assignment.routeNumber}: {assignment.routeDetails}
                                </h3>
                                <Badge className="bg-blue-100 text-blue-800 border-blue-200 w-fit">
                                  {assignment.status}
                                </Badge>
                              </div>
                              <p className="text-slate-600 mt-1">{formatDateTime(assignment.departureTime)}</p>

                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3 bg-slate-50 p-3 rounded-lg border border-slate-200">
                                <div>
                                  <p className="text-sm text-slate-500">Assignment Details</p>
                                  <div className="mt-1 space-y-1">
                                    <div className="flex items-center gap-2 text-sm">
                                      <Bus className="h-4 w-4 text-slate-400" />
                                      <span className="text-slate-700">{assignment.busNumber}</span>
                                    </div>
                                    <div className="flex items-center gap-2 text-sm">
                                      <User className="h-4 w-4 text-slate-400" />
                                      <span className="text-slate-700">{assignment.role}</span>
                                    </div>
                                  </div>
                                </div>

                                {assignment.routeInfo && (
                                  <div>
                                    <p className="text-sm text-slate-500">Journey Details</p>
                                    <div className="mt-1 space-y-1">
                                      <div className="flex items-center gap-2 text-sm">
                                        <Clock4 className="h-4 w-4 text-slate-400" />
                                        <span className="text-slate-700">
                                          {Math.floor(assignment.routeInfo.estimatedTime / 60)}h{" "}
                                          {assignment.routeInfo.estimatedTime % 60}m
                                        </span>
                                      </div>
                                      <div className="flex items-center gap-2 text-sm">
                                        <MapPin className="h-4 w-4 text-slate-400" />
                                        <span className="text-slate-700">{assignment.routeInfo.stops} stops</span>
                                      </div>
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center py-12 text-center">
                        <Calendar className="h-16 w-16 text-slate-300 mb-4" />
                        <h3 className="text-xl font-medium text-slate-900 mb-2">No Upcoming Assignments</h3>
                        <p className="text-slate-600 max-w-md">
                          You don't have any upcoming assignments scheduled for the next days.
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="weekly" className="space-y-6">
                <Card className="border-none shadow-md">
                  <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
                    <CardTitle>Weekly Schedule</CardTitle>
                    <CardDescription className="text-blue-100">Your assignments for the week</CardDescription>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
                      {["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"].map((day, index) => {
                        const today = new Date()
                        const dayDate = addDays(today, index - today.getDay() + 1) // Calculate the date for this day

                        // Find assignments for this day
                        const dayAssignments = crewAssignments.filter((assignment) => {
                          try {
                            const assignmentDate = parseISO(assignment.departureTime)
                            return (
                              assignmentDate.getDate() === dayDate.getDate() &&
                              assignmentDate.getMonth() === dayDate.getMonth() &&
                              assignmentDate.getFullYear() === dayDate.getFullYear()
                            )
                          } catch (e) {
                            return false
                          }
                        })

                        const hasAssignment = dayAssignments.length > 0
                        const assignment = hasAssignment ? dayAssignments[0] : null

                        return (
                          <Card key={day} className="border border-slate-200 shadow-sm">
                            <CardHeader className={`pb-2 ${isToday(dayDate) ? "bg-blue-50" : ""}`}>
                              <CardTitle className="text-base flex justify-between items-center">
                                <span>{day}</span>
                                {isToday(dayDate) && (
                                  <Badge className="bg-blue-100 text-blue-800 border-blue-200">Today</Badge>
                                )}
                              </CardTitle>
                              <CardDescription className="text-xs">{format(dayDate, "MMM dd, yyyy")}</CardDescription>
                            </CardHeader>
                            <CardContent>
                              {hasAssignment ? (
                                <div className="space-y-2">
                                  <div className="text-sm font-medium text-slate-900">
                                    Route {assignment.routeNumber}
                                  </div>
                                  <div className="text-xs text-slate-600">
                                    {formatDateTime(assignment.departureTime)}
                                  </div>
                                  <Badge
                                    className={
                                      assignment.status === "Completed"
                                        ? "bg-green-100 text-green-800 border-green-200"
                                        : assignment.status === "In Progress"
                                          ? "bg-purple-100 text-purple-800 border-purple-200"
                                          : "bg-blue-100 text-blue-800 border-blue-200"
                                    }
                                  >
                                    {assignment.status}
                                  </Badge>
                                  <div className="text-xs text-slate-500 mt-1">{assignment.role}</div>
                                </div>
                              ) : (
                                <div className="text-sm text-slate-600 py-2">No assignment</div>
                              )}
                            </CardContent>
                          </Card>
                        )
                      })}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </>
        )}
      </main>
    </div>
  )

  function calculateDutyHours(checkInTime) {
    const checkIn = new Date(checkInTime)
    const now = new Date()
    const diffMs = now - checkIn
    const diffHrs = diffMs / (1000 * 60 * 60)
    setDutyHours(Number.parseFloat(diffHrs.toFixed(2)))
  }
}
