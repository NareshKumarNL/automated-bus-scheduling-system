import type { ReactNode } from "react"

export default function CrewDashboardLayout({ children }: { children: ReactNode }) {
  return children
}
