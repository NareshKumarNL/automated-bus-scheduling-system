"use client"

import { useState } from "react"
import { useAppStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Search, Edit, Trash, MapPin, Map, AlertCircle, X } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export default function RoutesPage() {
  const { routes, addRoute, updateRoute, deleteRoute } = useAppStore()
  const [searchQuery, setSearchQuery] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [newRoute, setNewRoute] = useState({
    routeNumber: "",
    startPoint: "",
    endPoint: "",
    estimatedTime: "",
    stops: "",
  })
  const [editingRoute, setEditingRoute] = useState(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [routeToDelete, setRouteToDelete] = useState(null)
  const [isViewRouteDialogOpen, setIsViewRouteDialogOpen] = useState(false)
  const [routeToView, setRouteToView] = useState(null)

  const filteredRoutes = routes.filter((route) => {
    // Search filter
    const matchesSearch =
      route.routeNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      route.startPoint.toLowerCase().includes(searchQuery.toLowerCase()) ||
      route.endPoint.toLowerCase().includes(searchQuery.toLowerCase())

    // Status filter
    const matchesStatus = filterStatus === "all" || route.status === filterStatus

    return matchesSearch && matchesStatus
  })

  const handleAddRoute = () => {
    addRoute({
      routeNumber: newRoute.routeNumber,
      startPoint: newRoute.startPoint,
      endPoint: newRoute.endPoint,
      estimatedTime: Number.parseInt(newRoute.estimatedTime),
      stops: Number.parseInt(newRoute.stops),
      status: "Active",
    })
    setNewRoute({
      routeNumber: "",
      startPoint: "",
      endPoint: "",
      estimatedTime: "",
      stops: "",
    })
    setIsAddDialogOpen(false)
  }

  const handleEditRoute = () => {
    updateRoute(editingRoute.id, editingRoute)
    setIsEditDialogOpen(false)
    setEditingRoute(null)
  }

  const handleDeleteRoute = () => {
    if (routeToDelete) {
      deleteRoute(routeToDelete.id)
      setIsDeleteDialogOpen(false)
      setRouteToDelete(null)
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "Active":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Active
          </Badge>
        )
      case "Diverted":
        return (
          <Badge variant="secondary" className="bg-blue-50 text-blue-700 border-blue-200">
            Diverted
          </Badge>
        )
      case "Suspended":
        return (
          <Badge variant="destructive" className="bg-red-50 text-red-700 border-red-200">
            Suspended
          </Badge>
        )
      default:
        return <Badge>{status}</Badge>
    }
  }

  const formatTime = (minutes) => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return `${hours}h ${mins}m`
  }

  const resetFilters = () => {
    setSearchQuery("")
    setFilterStatus("all")
  }

  return (
    <div className="flex-1 space-y-4 p-4 pt-6 md:p-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">Route Management</h2>
          <p className="text-slate-600">Optimize your bus routes and schedules</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white">
              <Map className="mr-2 h-4 w-4" />
              Add Route
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-white border-none shadow-xl">
            <DialogHeader>
              <DialogTitle className="text-slate-900">Add New Route</DialogTitle>
              <DialogDescription className="text-slate-600">Enter the details of the new bus route.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="routeNumber" className="text-slate-700">
                  Route Number
                </Label>
                <Input
                  id="routeNumber"
                  placeholder="e.g., 423"
                  value={newRoute.routeNumber}
                  onChange={(e) => setNewRoute({ ...newRoute, routeNumber: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="startPoint" className="text-slate-700">
                  Start Point
                </Label>
                <Input
                  id="startPoint"
                  placeholder="e.g., Chennai"
                  value={newRoute.startPoint}
                  onChange={(e) => setNewRoute({ ...newRoute, startPoint: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="endPoint" className="text-slate-700">
                  End Point
                </Label>
                <Input
                  id="endPoint"
                  placeholder="e.g., Coimbatore"
                  value={newRoute.endPoint}
                  onChange={(e) => setNewRoute({ ...newRoute, endPoint: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="estimatedTime" className="text-slate-700">
                    Estimated Time (mins)
                  </Label>
                  <Input
                    id="estimatedTime"
                    type="number"
                    placeholder="e.g., 180"
                    value={newRoute.estimatedTime}
                    onChange={(e) => setNewRoute({ ...newRoute, estimatedTime: e.target.value })}
                    className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="stops" className="text-slate-700">
                    Number of Stops
                  </Label>
                  <Input
                    id="stops"
                    type="number"
                    placeholder="e.g., 8"
                    value={newRoute.stops}
                    onChange={(e) => setNewRoute({ ...newRoute, stops: e.target.value })}
                    className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsAddDialogOpen(false)}
                className="border-slate-200 text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddRoute}
                disabled={
                  !newRoute.routeNumber ||
                  !newRoute.startPoint ||
                  !newRoute.endPoint ||
                  !newRoute.estimatedTime ||
                  !newRoute.stops
                }
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
              >
                Add Route
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-none shadow-md">
        <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
          <CardTitle>Bus Routes</CardTitle>
          <CardDescription className="text-blue-100">
            Manage bus routes, stops, and estimated travel times
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col space-y-4 md:flex-row md:items-center md:space-y-0 gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
              <Input
                type="search"
                placeholder="Search by route number or location..."
                className="pl-8 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-[150px] border-slate-200 focus:ring-blue-500">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="Diverted">Diverted</SelectItem>
                  <SelectItem value="Suspended">Suspended</SelectItem>
                </SelectContent>
              </Select>

              <Button
                variant="outline"
                className="border-slate-200 text-slate-700 hover:bg-slate-50"
                onClick={resetFilters}
              >
                <X className="mr-2 h-4 w-4" />
                Reset
              </Button>
            </div>
          </div>
          <div className="rounded-md border border-slate-200 overflow-hidden">
            <Table>
              <TableHeader className="bg-slate-50">
                <TableRow className="hover:bg-slate-100/50">
                  <TableHead className="text-slate-700">Route Number</TableHead>
                  <TableHead className="text-slate-700">Start Point</TableHead>
                  <TableHead className="text-slate-700">End Point</TableHead>
                  <TableHead className="text-slate-700">Est. Time</TableHead>
                  <TableHead className="text-slate-700">Stops</TableHead>
                  <TableHead className="text-slate-700">Status</TableHead>
                  <TableHead className="text-right text-slate-700">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRoutes.length > 0 ? (
                  filteredRoutes.map((route) => (
                    <TableRow key={route.id} className="hover:bg-slate-50">
                      <TableCell className="font-medium text-slate-800">Route {route.routeNumber}</TableCell>
                      <TableCell className="text-slate-700">{route.startPoint}</TableCell>
                      <TableCell className="text-slate-700">{route.endPoint}</TableCell>
                      <TableCell className="text-slate-700">{formatTime(route.estimatedTime)}</TableCell>
                      <TableCell className="text-slate-700">{route.stops}</TableCell>
                      <TableCell>{getStatusBadge(route.status)}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-slate-600 hover:text-blue-600 hover:bg-blue-50"
                            onClick={() => {
                              setRouteToView(route)
                              setIsViewRouteDialogOpen(true)
                            }}
                          >
                            <MapPin className="h-4 w-4" />
                            <span className="sr-only">View Map</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-slate-600 hover:text-blue-600 hover:bg-blue-50"
                            onClick={() => {
                              setEditingRoute({ ...route })
                              setIsEditDialogOpen(true)
                            }}
                          >
                            <Edit className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-slate-600 hover:text-red-600 hover:bg-red-50"
                            onClick={() => {
                              setRouteToDelete(route)
                              setIsDeleteDialogOpen(true)
                            }}
                          >
                            <Trash className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      <div className="flex flex-col items-center justify-center text-slate-500">
                        <AlertCircle className="h-8 w-8 mb-2" />
                        <p>No routes found</p>
                        <p className="text-sm">Try adjusting your search or filters</p>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-white border-none shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-slate-900">Edit Route</DialogTitle>
            <DialogDescription className="text-slate-600">Make changes to the route details.</DialogDescription>
          </DialogHeader>
          {editingRoute && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-routeNumber" className="text-slate-700">
                  Route Number
                </Label>
                <Input
                  id="edit-routeNumber"
                  placeholder="e.g., 423"
                  value={editingRoute.routeNumber}
                  onChange={(e) => setEditingRoute({ ...editingRoute, routeNumber: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-startPoint" className="text-slate-700">
                  Start Point
                </Label>
                <Input
                  id="edit-startPoint"
                  placeholder="e.g., Chennai"
                  value={editingRoute.startPoint}
                  onChange={(e) => setEditingRoute({ ...editingRoute, startPoint: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-endPoint" className="text-slate-700">
                  End Point
                </Label>
                <Input
                  id="edit-endPoint"
                  placeholder="e.g., Coimbatore"
                  value={editingRoute.endPoint}
                  onChange={(e) => setEditingRoute({ ...editingRoute, endPoint: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="edit-estimatedTime" className="text-slate-700">
                    Estimated Time (mins)
                  </Label>
                  <Input
                    id="edit-estimatedTime"
                    type="number"
                    placeholder="e.g., 180"
                    value={editingRoute.estimatedTime}
                    onChange={(e) =>
                      setEditingRoute({ ...editingRoute, estimatedTime: Number.parseInt(e.target.value) })
                    }
                    className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-stops" className="text-slate-700">
                    Number of Stops
                  </Label>
                  <Input
                    id="edit-stops"
                    type="number"
                    placeholder="e.g., 8"
                    value={editingRoute.stops}
                    onChange={(e) => setEditingRoute({ ...editingRoute, stops: Number.parseInt(e.target.value) })}
                    className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-status" className="text-slate-700">
                  Status
                </Label>
                <Select
                  value={editingRoute.status}
                  onValueChange={(value) =>
                    setEditingRoute({
                      ...editingRoute,
                      status: value,
                    })
                  }
                >
                  <SelectTrigger id="edit-status" className="border-slate-200 focus:ring-blue-500">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Diverted">Diverted</SelectItem>
                    <SelectItem value="Suspended">Suspended</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsEditDialogOpen(false)}
              className="border-slate-200 text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </Button>
            <Button
              onClick={handleEditRoute}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete Route
              {routeToDelete
                ? ` ${routeToDelete.routeNumber} (${routeToDelete.startPoint} - ${routeToDelete.endPoint})`
                : ""}
              . This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteRoute} className="bg-red-600 hover:bg-red-700 text-white">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* View Route Dialog */}
      <Dialog open={isViewRouteDialogOpen} onOpenChange={setIsViewRouteDialogOpen}>
        <DialogContent className="bg-white border-none shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-slate-900">Route Details</DialogTitle>
            <DialogDescription className="text-slate-600">
              {routeToView && `Route ${routeToView.routeNumber}: ${routeToView.startPoint} to ${routeToView.endPoint}`}
            </DialogDescription>
          </DialogHeader>
          {routeToView && (
            <div className="py-4">
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 mb-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Status:</span>
                    <span>{getStatusBadge(routeToView.status)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Estimated Travel Time:</span>
                    <span className="font-medium text-slate-900">{formatTime(routeToView.estimatedTime)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Number of Stops:</span>
                    <span className="font-medium text-slate-900">{routeToView.stops}</span>
                  </div>
                </div>
              </div>

              <div className="rounded-lg overflow-hidden border border-slate-200 aspect-video bg-slate-100 flex items-center justify-center">
                <div className="text-center text-slate-500">
                  <Map className="mx-auto h-12 w-12 mb-2" />
                  <p>Route map would be displayed here</p>
                  <p className="text-sm">
                    {routeToView.startPoint} → {routeToView.endPoint}
                  </p>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              onClick={() => setIsViewRouteDialogOpen(false)}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
