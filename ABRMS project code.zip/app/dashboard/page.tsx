"use client"

import Link from "next/link"
import { useAppStore } from "@/lib/store"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Bus, Calendar, Clock, MapPin, Users, TrendingUp, BarChart3, Activity } from "lucide-react"
import { LineChart } from "@/components/charts/line-chart"
import { BarChart } from "@/components/charts/bar-chart"

export default function DashboardPage() {
  const { buses, crews, routes, schedules, emergencies, analytics } = useAppStore()

  // Calculate summary statistics
  const activeBuses = buses.filter((bus) => bus.isAvailable && bus.status === "Active").length
  const activeCrews = crews.filter((crew) => crew.isAvailable).length
  const activeRoutes = routes.filter((route) => route.status === "Active").length
  const todayTrips = schedules.filter((schedule) => {
    const scheduleDate = new Date(schedule.departureTime)
    const today = new Date()
    return (
      scheduleDate.getDate() === today.getDate() &&
      scheduleDate.getMonth() === today.getMonth() &&
      scheduleDate.getFullYear() === today.getFullYear()
    )
  }).length

  // Get today's schedules
  const todaySchedules = schedules
    .filter((schedule) => {
      const scheduleDate = new Date(schedule.departureTime)
      const today = new Date()
      return (
        scheduleDate.getDate() === today.getDate() &&
        scheduleDate.getMonth() === today.getMonth() &&
        scheduleDate.getFullYear() === today.getFullYear()
      )
    })
    .sort((a, b) => new Date(a.departureTime).getTime() - new Date(b.departureTime).getTime())
    .slice(0, 5)

  // Get recent alerts
  const recentAlerts = emergencies
    .filter((emergency) => emergency.status === "In Progress")
    .sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime())
    .slice(0, 3)

  const formatDateTime = (dateTimeStr) => {
    const date = new Date(dateTimeStr)
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

  return (
    <div className="flex-1 space-y-4 p-4 pt-6 md:p-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">Dashboard</h2>
          <p className="text-slate-600">Welcome to SmartTransit management system</p>
        </div>
        <div className="flex items-center gap-2">
          <Link href="/dashboard/schedules">
            <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white">
              <Calendar className="mr-2 h-4 w-4" />
              Schedule Bus
            </Button>
          </Link>
          <Link href="/dashboard/analytics">
            <Button
              variant="outline"
              className="border-slate-200 text-slate-700 hover:text-blue-600 hover:border-blue-200"
            >
              <BarChart3 className="mr-2 h-4 w-4" />
              View Analytics
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-700">Total Buses</CardTitle>
            <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
              <Bus className="h-4 w-4 text-blue-600" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">{buses.length}</div>
            <div className="flex items-center text-xs text-green-600">
              <TrendingUp className="mr-1 h-3 w-3" />
              <span>{activeBuses} active buses</span>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-700">Active Crews</CardTitle>
            <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center">
              <Users className="h-4 w-4 text-purple-600" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">{crews.length}</div>
            <div className="flex items-center text-xs text-green-600">
              <TrendingUp className="mr-1 h-3 w-3" />
              <span>{activeCrews} available for duty</span>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-700">Routes</CardTitle>
            <div className="h-8 w-8 rounded-full bg-emerald-100 flex items-center justify-center">
              <MapPin className="h-4 w-4 text-emerald-600" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">{routes.length}</div>
            <div className="flex items-center text-xs text-green-600">
              <TrendingUp className="mr-1 h-3 w-3" />
              <span>{activeRoutes} active routes</span>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-700">Today's Trips</CardTitle>
            <div className="h-8 w-8 rounded-full bg-orange-100 flex items-center justify-center">
              <Clock className="h-4 w-4 text-orange-600" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">{todayTrips}</div>
            <div className="flex items-center text-xs text-green-600">
              <Activity className="mr-1 h-3 w-3" />
              <span>{analytics.onTimePerformance}% on-time performance</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="bg-slate-100 p-1">
          <TabsTrigger value="overview" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            Overview
          </TabsTrigger>
          <TabsTrigger value="analytics" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            Analytics
          </TabsTrigger>
          <TabsTrigger value="reports" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            Reports
          </TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <Card className="col-span-4 border-none shadow-md">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
                <CardTitle>Today's Schedule Overview</CardTitle>
              </CardHeader>
              <CardContent className="pl-2">
                <div className="rounded-md border border-slate-200">
                  <div className="flex items-center justify-between border-b px-4 py-3 font-medium bg-slate-50 text-slate-700">
                    <div className="w-[180px]">Route</div>
                    <div className="w-[180px]">Bus Number</div>
                    <div className="w-[180px]">Crew</div>
                    <div className="w-[180px]">Departure</div>
                  </div>
                  {todaySchedules.length > 0 ? (
                    todaySchedules.map((schedule) => (
                      <div
                        key={schedule.id}
                        className="flex items-center justify-between border-b px-4 py-3 last:border-0 hover:bg-slate-50"
                      >
                        <div className="w-[180px] text-slate-700">Route {schedule.routeNumber}</div>
                        <div className="w-[180px] text-slate-700">{schedule.busNumber}</div>
                        <div className="w-[180px] text-slate-700">{schedule.driver}</div>
                        <div className="w-[180px] text-slate-700">{formatDateTime(schedule.departureTime)}</div>
                      </div>
                    ))
                  ) : (
                    <div className="flex items-center justify-center py-8 text-slate-500">No schedules for today</div>
                  )}
                </div>
              </CardContent>
            </Card>
            <Card className="col-span-3 border-none shadow-md">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
                <CardTitle>Alerts & Notifications</CardTitle>
                <CardDescription className="text-blue-100">System alerts and important notifications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentAlerts.length > 0 ? (
                    recentAlerts.map((alert) => (
                      <div
                        key={alert.id}
                        className="flex items-start gap-4 rounded-md border border-slate-200 p-4 bg-slate-50 hover:bg-white transition-colors"
                      >
                        <AlertTriangle className="mt-1 h-5 w-5 text-amber-500" />
                        <div>
                          <p className="font-medium text-slate-800">
                            {alert.type} Alert - {alert.busNumber}
                          </p>
                          <p className="text-sm text-slate-600">{alert.description}</p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="flex items-start gap-4 rounded-md border border-slate-200 p-4 bg-slate-50">
                      <div>
                        <p className="font-medium text-slate-800">No active alerts</p>
                        <p className="text-sm text-slate-600">All systems operating normally</p>
                      </div>
                    </div>
                  )}

                  <div className="flex items-start gap-4 rounded-md border border-slate-200 p-4 bg-slate-50 hover:bg-white transition-colors">
                    <Bus className="mt-1 h-5 w-5 text-blue-500" />
                    <div>
                      <p className="font-medium text-slate-800">Bus Maintenance Due</p>
                      <p className="text-sm text-slate-600">
                        {
                          buses.filter((bus) => {
                            const lastDate = new Date(bus.lastMaintenance)
                            const today = new Date()
                            const diffTime = Math.abs(today - lastDate)
                            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
                            return diffDays > 30
                          }).length
                        }{" "}
                        buses scheduled for maintenance
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="analytics" className="space-y-4">
          <Card className="border-none shadow-md">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
              <CardTitle>Analytics Dashboard</CardTitle>
              <CardDescription className="text-blue-100">
                View detailed performance metrics and statistics
              </CardDescription>
            </CardHeader>
            <CardContent className="h-[400px] flex items-center justify-center">
              <div className="w-full h-full flex flex-col items-center justify-center">
                <div className="w-full h-[350px]">
                  <LineChart
                    data={analytics.monthlyRevenue.map((val) => val / 1000000)}
                    labels={months}
                    title="Monthly Revenue (in Millions ₹)"
                    width={800}
                    height={350}
                    lineColor="#4f46e5"
                    fillColor="rgba(79, 70, 229, 0.1)"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="reports" className="space-y-4">
          <Card className="border-none shadow-md">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
              <CardTitle>Route Performance</CardTitle>
              <CardDescription className="text-blue-100">Performance by route</CardDescription>
            </CardHeader>
            <CardContent className="h-[400px] flex items-center justify-center">
              <div className="w-full h-full flex flex-col items-center justify-center">
                <div className="w-full h-[350px]">
                  <BarChart
                    data={analytics.routePerformance.map((item) => item.performance)}
                    labels={analytics.routePerformance.map((item) => `Route ${item.route}`)}
                    title="On-Time Performance by Route (%)"
                    width={800}
                    height={350}
                    color="#4f46e5"
                    barColor="#818cf8"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
