"use client"

import { useState } from "react"
import { useAppStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Search, Edit, Trash, AlertCircle, BusFront, Wrench, X } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export default function BusesPage() {
  const { buses, addBus, updateBus, deleteBus } = useAppStore()
  const [searchQuery, setSearchQuery] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterMaintenanceDue, setFilterMaintenanceDue] = useState(false)
  const [newBus, setNewBus] = useState({
    busNumber: "",
    model: "",
    capacity: "",
  })
  const [editingBus, setEditingBus] = useState(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [busToDelete, setBusToDelete] = useState(null)
  const [isMaintenanceDialogOpen, setIsMaintenanceDialogOpen] = useState(false)
  const [busForMaintenance, setBusForMaintenance] = useState(null)

  const filteredBuses = buses.filter((bus) => {
    // Search filter
    const matchesSearch =
      bus.busNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      bus.model.toLowerCase().includes(searchQuery.toLowerCase())

    // Status filter
    const matchesStatus = filterStatus === "all" || bus.status === filterStatus

    // Maintenance due filter
    let matchesMaintenance = true
    if (filterMaintenanceDue) {
      const lastDate = new Date(bus.lastMaintenance)
      const today = new Date()
      const diffTime = Math.abs(today - lastDate)
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
      matchesMaintenance = diffDays > 30
    }

    return matchesSearch && matchesStatus && matchesMaintenance
  })

  const handleAddBus = () => {
    addBus({
      busNumber: newBus.busNumber,
      model: newBus.model,
      capacity: Number.parseInt(newBus.capacity),
      isAvailable: true,
      status: "Active",
      lastMaintenance: new Date().toISOString().split("T")[0],
    })
    setNewBus({ busNumber: "", model: "", capacity: "" })
    setIsAddDialogOpen(false)
  }

  const handleEditBus = () => {
    updateBus(editingBus.id, editingBus)
    setIsEditDialogOpen(false)
    setEditingBus(null)
  }

  const handleDeleteBus = () => {
    if (busToDelete) {
      deleteBus(busToDelete.id)
      setIsDeleteDialogOpen(false)
      setBusToDelete(null)
    }
  }

  const handleMaintenanceComplete = () => {
    if (busForMaintenance) {
      const updatedBus = {
        ...busForMaintenance,
        lastMaintenance: new Date().toISOString().split("T")[0],
        status: "Active",
        isAvailable: true,
      }
      updateBus(busForMaintenance.id, updatedBus)
      setIsMaintenanceDialogOpen(false)
      setBusForMaintenance(null)
    }
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "Active":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Active
          </Badge>
        )
      case "Maintenance":
        return (
          <Badge variant="secondary" className="bg-blue-50 text-blue-700 border-blue-200">
            Maintenance
          </Badge>
        )
      case "Out of Service":
        return (
          <Badge variant="destructive" className="bg-red-50 text-red-700 border-red-200">
            Out of Service
          </Badge>
        )
      default:
        return <Badge>{status}</Badge>
    }
  }

  const needsMaintenance = (lastMaintenance) => {
    const lastDate = new Date(lastMaintenance)
    const today = new Date()
    const diffTime = Math.abs(today - lastDate)
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays > 30
  }

  const resetFilters = () => {
    setSearchQuery("")
    setFilterStatus("all")
    setFilterMaintenanceDue(false)
  }

  return (
    <div className="flex-1 space-y-4 p-4 pt-6 md:p-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">Fleet Management</h2>
          <p className="text-slate-600">Manage your bus fleet and maintenance schedules</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white">
              <BusFront className="mr-2 h-4 w-4" />
              Add Bus
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-white border-none shadow-xl">
            <DialogHeader>
              <DialogTitle className="text-slate-900">Add New Bus</DialogTitle>
              <DialogDescription className="text-slate-600">Enter the details of the new bus.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="busNumber" className="text-slate-700">
                  Bus Number
                </Label>
                <Input
                  id="busNumber"
                  placeholder="e.g., TN-01-N-1234"
                  value={newBus.busNumber}
                  onChange={(e) => setNewBus({ ...newBus, busNumber: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="model" className="text-slate-700">
                  Model
                </Label>
                <Input
                  id="model"
                  placeholder="e.g., Ashok Leyland Viking"
                  value={newBus.model}
                  onChange={(e) => setNewBus({ ...newBus, model: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="capacity" className="text-slate-700">
                  Capacity
                </Label>
                <Input
                  id="capacity"
                  type="number"
                  placeholder="e.g., 40"
                  value={newBus.capacity}
                  onChange={(e) => setNewBus({ ...newBus, capacity: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsAddDialogOpen(false)}
                className="border-slate-200 text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddBus}
                disabled={!newBus.busNumber || !newBus.model || !newBus.capacity}
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
              >
                Add Bus
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      <Card className="border-none shadow-md">
        <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
          <CardTitle>Fleet Inventory</CardTitle>
          <CardDescription className="text-blue-100">
            Manage bus fleet, maintenance schedules, and availability
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col space-y-4 md:flex-row md:items-center md:space-y-0 gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
              <Input
                type="search"
                placeholder="Search by bus number or model..."
                className="pl-8 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-[150px] border-slate-200 focus:ring-blue-500">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="Maintenance">Maintenance</SelectItem>
                  <SelectItem value="Out of Service">Out of Service</SelectItem>
                </SelectContent>
              </Select>

              <div className="flex items-center space-x-2">
                <Label htmlFor="maintenance-due" className="text-sm font-normal cursor-pointer">
                  Maintenance Due
                </Label>
                <input
                  type="checkbox"
                  id="maintenance-due"
                  checked={filterMaintenanceDue}
                  onChange={(e) => setFilterMaintenanceDue(e.target.checked)}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500"
                />
              </div>

              <Button
                variant="outline"
                className="border-slate-200 text-slate-700 hover:bg-slate-50"
                onClick={resetFilters}
              >
                <X className="mr-2 h-4 w-4" />
                Reset
              </Button>
            </div>
          </div>
          <div className="rounded-md border border-slate-200 overflow-hidden">
            <Table>
              <TableHeader className="bg-slate-50">
                <TableRow className="hover:bg-slate-100/50">
                  <TableHead className="text-slate-700">Bus Number</TableHead>
                  <TableHead className="text-slate-700">Model</TableHead>
                  <TableHead className="text-slate-700">Capacity</TableHead>
                  <TableHead className="text-slate-700">Status</TableHead>
                  <TableHead className="text-slate-700">Last Maintenance</TableHead>
                  <TableHead className="text-right text-slate-700">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredBuses.length > 0 ? (
                  filteredBuses.map((bus) => (
                    <TableRow key={bus.id} className="hover:bg-slate-50">
                      <TableCell className="font-medium text-slate-800">{bus.busNumber}</TableCell>
                      <TableCell className="text-slate-700">{bus.model}</TableCell>
                      <TableCell className="text-slate-700">{bus.capacity}</TableCell>
                      <TableCell>{getStatusBadge(bus.status)}</TableCell>
                      <TableCell className="flex items-center gap-2 text-slate-700">
                        {bus.lastMaintenance}
                        {needsMaintenance(bus.lastMaintenance) && (
                          <AlertCircle className="h-4 w-4 text-amber-500" title="Maintenance due" />
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          {bus.status === "Maintenance" && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-slate-600 hover:text-green-600 hover:bg-green-50"
                              onClick={() => {
                                setBusForMaintenance(bus)
                                setIsMaintenanceDialogOpen(true)
                              }}
                            >
                              <Wrench className="h-4 w-4" />
                              <span className="sr-only">Complete Maintenance</span>
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-slate-600 hover:text-blue-600 hover:bg-blue-50"
                            onClick={() => {
                              setEditingBus({ ...bus })
                              setIsEditDialogOpen(true)
                            }}
                          >
                            <Edit className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-slate-600 hover:text-red-600 hover:bg-red-50"
                            onClick={() => {
                              setBusToDelete(bus)
                              setIsDeleteDialogOpen(true)
                            }}
                          >
                            <Trash className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                      <div className="flex flex-col items-center justify-center text-slate-500">
                        <AlertCircle className="h-8 w-8 mb-2" />
                        <p>No buses found</p>
                        <p className="text-sm">Try adjusting your search or filters</p>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-white border-none shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-slate-900">Edit Bus</DialogTitle>
            <DialogDescription className="text-slate-600">Make changes to the bus details.</DialogDescription>
          </DialogHeader>
          {editingBus && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-busNumber" className="text-slate-700">
                  Bus Number
                </Label>
                <Input
                  id="edit-busNumber"
                  placeholder="e.g., TN-01-N-1234"
                  value={editingBus.busNumber}
                  onChange={(e) => setEditingBus({ ...editingBus, busNumber: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-model" className="text-slate-700">
                  Model
                </Label>
                <Input
                  id="edit-model"
                  placeholder="e.g., Ashok Leyland Viking"
                  value={editingBus.model}
                  onChange={(e) => setEditingBus({ ...editingBus, model: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-capacity" className="text-slate-700">
                  Capacity
                </Label>
                <Input
                  id="edit-capacity"
                  type="number"
                  placeholder="e.g., 40"
                  value={editingBus.capacity}
                  onChange={(e) => setEditingBus({ ...editingBus, capacity: Number.parseInt(e.target.value) })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-status" className="text-slate-700">
                  Status
                </Label>
                <Select
                  value={editingBus.status}
                  onValueChange={(value) =>
                    setEditingBus({
                      ...editingBus,
                      status: value,
                      isAvailable: value === "Active",
                    })
                  }
                >
                  <SelectTrigger id="edit-status" className="border-slate-200 focus:ring-blue-500">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Maintenance">Maintenance</SelectItem>
                    <SelectItem value="Out of Service">Out of Service</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-lastMaintenance" className="text-slate-700">
                  Last Maintenance Date
                </Label>
                <Input
                  id="edit-lastMaintenance"
                  type="date"
                  value={editingBus.lastMaintenance}
                  onChange={(e) => setEditingBus({ ...editingBus, lastMaintenance: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsEditDialogOpen(false)}
              className="border-slate-200 text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </Button>
            <Button
              onClick={handleEditBus}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the bus
              {busToDelete ? ` ${busToDelete.busNumber} (${busToDelete.model})` : ""}. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteBus} className="bg-red-600 hover:bg-red-700 text-white">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Maintenance Complete Dialog */}
      <Dialog open={isMaintenanceDialogOpen} onOpenChange={setIsMaintenanceDialogOpen}>
        <DialogContent className="bg-white border-none shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-slate-900">Complete Maintenance</DialogTitle>
            <DialogDescription className="text-slate-600">
              Mark maintenance as complete for bus
              {busForMaintenance ? ` ${busForMaintenance.busNumber}` : ""}.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="text-slate-700">Completing maintenance will:</p>
            <ul className="list-disc list-inside mt-2 text-slate-600">
              <li>Update the last maintenance date to today</li>
              <li>Change the bus status to "Active"</li>
              <li>Make the bus available for scheduling</li>
            </ul>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsMaintenanceDialogOpen(false)}
              className="border-slate-200 text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </Button>
            <Button
              onClick={handleMaintenanceComplete}
              className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white"
            >
              Complete Maintenance
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
