"use client"

import { useState, useEffect } from "react"
import { useAppStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format, isSameDay, parseISO, isAfter, isBefore, startOfDay } from "date-fns"
import { CalendarIcon, Search, CalendarDays, Edit, Trash, AlertCircle, X } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export default function SchedulesPage() {
  const { schedules, routes, buses, crews, addSchedule, updateSchedule, deleteSchedule } = useAppStore()
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [filterRoute, setFilterRoute] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [newSchedule, setNewSchedule] = useState({
    routeNumber: "",
    busNumber: "",
    driver: "",
    conductor: "",
    departureTime: "",
    departureDate: new Date(),
  })
  const [editingSchedule, setEditingSchedule] = useState(null)
  const [scheduleToDelete, setScheduleToDelete] = useState(null)

  // Filter schedules based on current tab and filters
  const filterSchedules = (tab) => {
    const now = new Date()

    return schedules
      .filter((schedule) => {
        // Parse the departure time
        const departureTime = parseISO(schedule.departureTime)

        // Check if the schedule matches the current tab
        const matchesTab =
          (tab === "today" && isSameDay(departureTime, now)) ||
          (tab === "upcoming" && isAfter(departureTime, now) && !isSameDay(departureTime, now)) ||
          (tab === "completed" && (schedule.status === "Completed" || isBefore(departureTime, startOfDay(now)))) ||
          tab === "all"

        // Apply search filter
        const matchesSearch =
          schedule.routeNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
          schedule.busNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
          schedule.driver.toLowerCase().includes(searchQuery.toLowerCase()) ||
          schedule.conductor.toLowerCase().includes(searchQuery.toLowerCase())

        // Apply route filter
        const matchesRoute = filterRoute === "all" || schedule.routeNumber === filterRoute

        // Apply status filter
        const matchesStatus = filterStatus === "all" || schedule.status === filterStatus

        return matchesTab && matchesSearch && matchesRoute && matchesStatus
      })
      .sort((a, b) => new Date(a.departureTime).getTime() - new Date(b.departureTime).getTime())
  }

  const availableDrivers = crews.filter((crew) => crew.role === "Driver" && crew.isAvailable)
  const availableConductors = crews.filter((crew) => crew.role === "Conductor" && crew.isAvailable)
  const availableBuses = buses.filter((bus) => bus.isAvailable && bus.status === "Active")

  // Update past schedules status to "Completed" on component mount
  useEffect(() => {
    const now = new Date()
    const updatedSchedules = schedules.map((schedule) => {
      const departureTime = parseISO(schedule.departureTime)
      if (isBefore(departureTime, now) && schedule.status === "Scheduled") {
        updateSchedule(schedule.id, { ...schedule, status: "Completed" })
        return { ...schedule, status: "Completed" }
      }
      return schedule
    })
  }, [])

  const handleAddSchedule = () => {
    // Combine date and time for departure
    const dateTime = new Date(newSchedule.departureDate)
    const [hours, minutes] = newSchedule.departureTime.split(":")
    dateTime.setHours(Number.parseInt(hours), Number.parseInt(minutes))

    const driverName = crews.find((d) => d.id.toString() === newSchedule.driver)?.name || ""
    const conductorName = crews.find((c) => c.id.toString() === newSchedule.conductor)?.name || ""

    // Determine status based on departure time
    const now = new Date()
    const status = isAfter(dateTime, now) ? "Scheduled" : "Completed"

    addSchedule({
      routeNumber: newSchedule.routeNumber,
      busNumber: newSchedule.busNumber,
      driver: driverName,
      conductor: conductorName,
      departureTime: dateTime.toISOString(),
      status,
    })

    setNewSchedule({
      routeNumber: "",
      busNumber: "",
      driver: "",
      conductor: "",
      departureTime: "",
      departureDate: new Date(),
    })
    setIsAddDialogOpen(false)
  }

  const handleEditSchedule = () => {
    if (editingSchedule) {
      // Combine date and time for departure
      let updatedDepartureTime = editingSchedule.departureTime

      if (editingSchedule.newDepartureDate && editingSchedule.newDepartureTime) {
        const dateTime = new Date(editingSchedule.newDepartureDate)
        const [hours, minutes] = editingSchedule.newDepartureTime.split(":")
        dateTime.setHours(Number.parseInt(hours), Number.parseInt(minutes))
        updatedDepartureTime = dateTime.toISOString()
      }

      // Create updated schedule object
      const updatedSchedule = {
        ...editingSchedule,
        departureTime: updatedDepartureTime,
        // Add other fields that might have been changed
      }

      // Remove temporary fields used for editing
      delete updatedSchedule.newDepartureDate
      delete updatedSchedule.newDepartureTime

      updateSchedule(editingSchedule.id, updatedSchedule)
      setIsEditDialogOpen(false)
      setEditingSchedule(null)
    }
  }

  const handleDeleteSchedule = () => {
    if (scheduleToDelete) {
      deleteSchedule(scheduleToDelete.id)
      setIsDeleteDialogOpen(false)
      setScheduleToDelete(null)
    }
  }

  const formatDateTime = (dateTimeStr) => {
    const date = new Date(dateTimeStr)
    return format(date, "MMM dd, yyyy HH:mm")
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "Scheduled":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Scheduled
          </Badge>
        )
      case "In Progress":
        return (
          <Badge variant="secondary" className="bg-purple-50 text-purple-700 border-purple-200">
            In Progress
          </Badge>
        )
      case "Completed":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Completed
          </Badge>
        )
      case "Cancelled":
        return (
          <Badge variant="destructive" className="bg-red-50 text-red-700 border-red-200">
            Cancelled
          </Badge>
        )
      default:
        return <Badge>{status}</Badge>
    }
  }

  const resetFilters = () => {
    setSearchQuery("")
    setFilterRoute("all")
    setFilterStatus("all")
    setSelectedDate(new Date())
  }

  return (
    <div className="flex-1 space-y-4 p-4 pt-6 md:p-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">Schedule Management</h2>
          <p className="text-slate-600">Create and manage bus schedules efficiently</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white">
              <CalendarDays className="mr-2 h-4 w-4" />
              Create Schedule
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md bg-white border-none shadow-xl">
            <DialogHeader>
              <DialogTitle className="text-slate-900">Create New Schedule</DialogTitle>
              <DialogDescription className="text-slate-600">
                Schedule a bus with crew for a specific route.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="route" className="text-slate-700">
                  Route
                </Label>
                <Select
                  value={newSchedule.routeNumber}
                  onValueChange={(value) => setNewSchedule({ ...newSchedule, routeNumber: value })}
                >
                  <SelectTrigger id="route" className="border-slate-200 focus:ring-blue-500">
                    <SelectValue placeholder="Select route" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    {routes.map((route) => (
                      <SelectItem key={route.id} value={route.routeNumber}>
                        Route {route.routeNumber} - {route.startPoint} to {route.endPoint}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="bus" className="text-slate-700">
                  Bus
                </Label>
                <Select
                  value={newSchedule.busNumber}
                  onValueChange={(value) => setNewSchedule({ ...newSchedule, busNumber: value })}
                >
                  <SelectTrigger id="bus" className="border-slate-200 focus:ring-blue-500">
                    <SelectValue placeholder="Select bus" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    {availableBuses.map((bus) => (
                      <SelectItem key={bus.id} value={bus.busNumber}>
                        {bus.busNumber} - {bus.model}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="driver" className="text-slate-700">
                  Driver
                </Label>
                <Select
                  value={newSchedule.driver}
                  onValueChange={(value) => setNewSchedule({ ...newSchedule, driver: value })}
                >
                  <SelectTrigger id="driver" className="border-slate-200 focus:ring-blue-500">
                    <SelectValue placeholder="Select driver" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    {availableDrivers.map((driver) => (
                      <SelectItem key={driver.id} value={driver.id.toString()}>
                        {driver.name} ({driver.employeeId})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="conductor" className="text-slate-700">
                  Conductor
                </Label>
                <Select
                  value={newSchedule.conductor}
                  onValueChange={(value) => setNewSchedule({ ...newSchedule, conductor: value })}
                >
                  <SelectTrigger id="conductor" className="border-slate-200 focus:ring-blue-500">
                    <SelectValue placeholder="Select conductor" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    {availableConductors.map((conductor) => (
                      <SelectItem key={conductor.id} value={conductor.id.toString()}>
                        {conductor.name} ({conductor.employeeId})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="departureDate" className="text-slate-700">
                    Departure Date
                  </Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal border-slate-200 text-slate-700"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {newSchedule.departureDate ? (
                          format(newSchedule.departureDate, "MMM dd, yyyy")
                        ) : (
                          <span>Pick a date</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 bg-white border-slate-200">
                      <CalendarComponent
                        mode="single"
                        selected={newSchedule.departureDate}
                        onSelect={(date) => setNewSchedule({ ...newSchedule, departureDate: date })}
                        initialFocus
                        className="border-slate-200"
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="departureTime" className="text-slate-700">
                    Departure Time
                  </Label>
                  <Input
                    id="departureTime"
                    type="time"
                    value={newSchedule.departureTime}
                    onChange={(e) => setNewSchedule({ ...newSchedule, departureTime: e.target.value })}
                    className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsAddDialogOpen(false)}
                className="border-slate-200 text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddSchedule}
                disabled={
                  !newSchedule.routeNumber ||
                  !newSchedule.busNumber ||
                  !newSchedule.driver ||
                  !newSchedule.conductor ||
                  !newSchedule.departureTime
                }
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
              >
                Create Schedule
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList className="bg-slate-100 p-1">
          <TabsTrigger value="all" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            All Schedules
          </TabsTrigger>
          <TabsTrigger value="today" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            Today
          </TabsTrigger>
          <TabsTrigger value="upcoming" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            Upcoming
          </TabsTrigger>
          <TabsTrigger value="completed" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            Completed
          </TabsTrigger>
        </TabsList>

        {["all", "today", "upcoming", "completed"].map((tab) => (
          <TabsContent key={tab} value={tab} className="space-y-4">
            <Card className="border-none shadow-md">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
                <CardTitle>
                  {tab === "all" && "All Schedules"}
                  {tab === "today" && "Today's Schedules"}
                  {tab === "upcoming" && "Upcoming Schedules"}
                  {tab === "completed" && "Completed Schedules"}
                </CardTitle>
                <CardDescription className="text-blue-100">
                  {tab === "all" && "View and manage all bus schedules"}
                  {tab === "today" && "View and manage today's bus schedules"}
                  {tab === "upcoming" && "View and manage upcoming bus schedules"}
                  {tab === "completed" && "View history of completed bus schedules"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col space-y-4 md:flex-row md:items-center md:space-y-0 gap-4 mb-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                    <Input
                      type="search"
                      placeholder="Search schedules..."
                      className="pl-8 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Select value={filterRoute} onValueChange={setFilterRoute}>
                      <SelectTrigger className="w-[150px] border-slate-200 focus:ring-blue-500">
                        <SelectValue placeholder="Route" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Routes</SelectItem>
                        {routes.map((route) => (
                          <SelectItem key={route.id} value={route.routeNumber}>
                            Route {route.routeNumber}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <Select value={filterStatus} onValueChange={setFilterStatus}>
                      <SelectTrigger className="w-[150px] border-slate-200 focus:ring-blue-500">
                        <SelectValue placeholder="Status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="Scheduled">Scheduled</SelectItem>
                        <SelectItem value="In Progress">In Progress</SelectItem>
                        <SelectItem value="Completed">Completed</SelectItem>
                        <SelectItem value="Cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>

                    <Button
                      variant="outline"
                      className="border-slate-200 text-slate-700 hover:bg-slate-50"
                      onClick={resetFilters}
                    >
                      <X className="mr-2 h-4 w-4" />
                      Reset
                    </Button>
                  </div>
                </div>
                <div className="rounded-md border border-slate-200 overflow-hidden">
                  <Table>
                    <TableHeader className="bg-slate-50">
                      <TableRow className="hover:bg-slate-100/50">
                        <TableHead className="text-slate-700">Route</TableHead>
                        <TableHead className="text-slate-700">Bus Number</TableHead>
                        <TableHead className="text-slate-700">Driver</TableHead>
                        <TableHead className="text-slate-700">Conductor</TableHead>
                        <TableHead className="text-slate-700">Departure</TableHead>
                        <TableHead className="text-slate-700">Status</TableHead>
                        <TableHead className="text-right text-slate-700">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filterSchedules(tab).length > 0 ? (
                        filterSchedules(tab).map((schedule) => (
                          <TableRow key={schedule.id} className="hover:bg-slate-50">
                            <TableCell className="font-medium text-slate-800">Route {schedule.routeNumber}</TableCell>
                            <TableCell className="text-slate-700">{schedule.busNumber}</TableCell>
                            <TableCell className="text-slate-700">{schedule.driver}</TableCell>
                            <TableCell className="text-slate-700">{schedule.conductor}</TableCell>
                            <TableCell className="text-slate-700">{formatDateTime(schedule.departureTime)}</TableCell>
                            <TableCell>{getStatusBadge(schedule.status)}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                {schedule.status !== "Completed" && (
                                  <>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="text-slate-600 hover:text-blue-600 hover:bg-blue-50"
                                      onClick={() => {
                                        // Get departure date and time for editing
                                        const departureDate = new Date(schedule.departureTime)
                                        const hours = departureDate.getHours().toString().padStart(2, "0")
                                        const minutes = departureDate.getMinutes().toString().padStart(2, "0")
                                        const departureTime = `${hours}:${minutes}`

                                        setEditingSchedule({
                                          ...schedule,
                                          newDepartureDate: departureDate,
                                          newDepartureTime: departureTime,
                                        })
                                        setIsEditDialogOpen(true)
                                      }}
                                    >
                                      <Edit className="h-4 w-4" />
                                      <span className="sr-only">Edit</span>
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="text-slate-600 hover:text-red-600 hover:bg-red-50"
                                      onClick={() => {
                                        setScheduleToDelete(schedule)
                                        setIsDeleteDialogOpen(true)
                                      }}
                                    >
                                      <Trash className="h-4 w-4" />
                                      <span className="sr-only">Delete</span>
                                    </Button>
                                  </>
                                )}
                                {schedule.status === "Completed" && (
                                  <span className="text-sm text-slate-400">Completed</span>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={7} className="h-24 text-center">
                            <div className="flex flex-col items-center justify-center text-slate-500">
                              <AlertCircle className="h-8 w-8 mb-2" />
                              <p>No schedules found</p>
                              <p className="text-sm">
                                {tab === "all" && "No schedules match your filters"}
                                {tab === "today" && "No schedules for today"}
                                {tab === "upcoming" && "No upcoming schedules"}
                                {tab === "completed" && "No completed schedules"}
                              </p>
                            </div>
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-md bg-white border-none shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-slate-900">Edit Schedule</DialogTitle>
            <DialogDescription className="text-slate-600">Update the schedule details.</DialogDescription>
          </DialogHeader>
          {editingSchedule && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-route" className="text-slate-700">
                  Route
                </Label>
                <Select
                  value={editingSchedule.routeNumber}
                  onValueChange={(value) => setEditingSchedule({ ...editingSchedule, routeNumber: value })}
                >
                  <SelectTrigger id="edit-route" className="border-slate-200 focus:ring-blue-500">
                    <SelectValue placeholder="Select route" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    {routes.map((route) => (
                      <SelectItem key={route.id} value={route.routeNumber}>
                        Route {route.routeNumber} - {route.startPoint} to {route.endPoint}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-status" className="text-slate-700">
                  Status
                </Label>
                <Select
                  value={editingSchedule.status}
                  onValueChange={(value) => setEditingSchedule({ ...editingSchedule, status: value })}
                >
                  <SelectTrigger id="edit-status" className="border-slate-200 focus:ring-blue-500">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    <SelectItem value="Scheduled">Scheduled</SelectItem>
                    <SelectItem value="In Progress">In Progress</SelectItem>
                    <SelectItem value="Cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="edit-departureDate" className="text-slate-700">
                    Departure Date
                  </Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal border-slate-200 text-slate-700"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {editingSchedule.newDepartureDate ? (
                          format(editingSchedule.newDepartureDate, "MMM dd, yyyy")
                        ) : (
                          <span>Pick a date</span>
                        )}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0 bg-white border-slate-200">
                      <CalendarComponent
                        mode="single"
                        selected={editingSchedule.newDepartureDate}
                        onSelect={(date) => setEditingSchedule({ ...editingSchedule, newDepartureDate: date })}
                        initialFocus
                        className="border-slate-200"
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-departureTime" className="text-slate-700">
                    Departure Time
                  </Label>
                  <Input
                    id="edit-departureTime"
                    type="time"
                    value={editingSchedule.newDepartureTime}
                    onChange={(e) => setEditingSchedule({ ...editingSchedule, newDepartureTime: e.target.value })}
                    className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsEditDialogOpen(false)}
              className="border-slate-200 text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </Button>
            <Button
              onClick={handleEditSchedule}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this schedule
              {scheduleToDelete
                ? ` for Route ${scheduleToDelete.routeNumber} at ${formatDateTime(scheduleToDelete.departureTime)}`
                : ""}
              . This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteSchedule} className="bg-red-600 hover:bg-red-700 text-white">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
