"use client"

import { useState } from "react"
import { useStore } from "@/lib/store"
import { format } from "date-fns"
import { Filter, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { DateRangePicker } from "@/components/crud/date-range-picker"
import { FilterSelect } from "@/components/crud/filter-select"
import type { DateRange } from "react-day-picker"

export default function PastSchedulesPage() {
  const { schedules, routes, buses } = useStore()
  const [searchQuery, setSearchQuery] = useState("")
  const [dateRange, setDateRange] = useState<DateRange | undefined>()
  const [routeFilter, setRouteFilter] = useState("")
  const [statusFilter, setStatusFilter] = useState("")

  // Get past schedules (schedules with departure date in the past)
  const pastSchedules = schedules.filter((schedule) => {
    const departureDate = new Date(schedule.departureTime)
    return departureDate < new Date()
  })

  // Filter schedules based on search query, date range, route, and status
  const filteredSchedules = pastSchedules.filter((schedule) => {
    const matchesSearch =
      schedule.id.toString().includes(searchQuery) ||
      routes
        .find((r) => r.id === schedule.routeId)
        ?.name.toLowerCase()
        .includes(searchQuery.toLowerCase()) ||
      buses
        .find((b) => b.id === schedule.busId)
        ?.registrationNumber.toLowerCase()
        .includes(searchQuery.toLowerCase())

    const matchesDateRange =
      !dateRange?.from ||
      (new Date(schedule.departureTime) >= dateRange.from &&
        (!dateRange.to || new Date(schedule.departureTime) <= dateRange.to))

    const matchesRoute = !routeFilter || schedule.routeId.toString() === routeFilter

    const matchesStatus = !statusFilter || schedule.status === statusFilter

    return matchesSearch && matchesDateRange && matchesRoute && matchesStatus
  })

  // Create route options for filter
  const routeOptions = routes.map((route) => ({
    value: route.id.toString(),
    label: route.name,
  }))

  // Create status options for filter
  const statusOptions = [
    { value: "completed", label: "Completed" },
    { value: "cancelled", label: "Cancelled" },
    { value: "delayed", label: "Delayed" },
  ]

  return (
    <div className="space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Past Schedules</h2>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-xl font-bold">Past Schedule Records</CardTitle>
          <div className="flex items-center space-x-2">
            <div className="relative w-64">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search schedules..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4 mb-4">
            <DateRangePicker dateRange={dateRange} onDateRangeChange={setDateRange} />
            <FilterSelect
              options={routeOptions}
              placeholder="Filter by route"
              value={routeFilter}
              onValueChange={setRouteFilter}
            />
            <FilterSelect
              options={statusOptions}
              placeholder="Filter by status"
              value={statusFilter}
              onValueChange={setStatusFilter}
            />
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Route</TableHead>
                  <TableHead>Bus</TableHead>
                  <TableHead>Departure</TableHead>
                  <TableHead>Arrival</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Tickets Sold</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSchedules.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      No past schedules found.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredSchedules.map((schedule) => {
                    const route = routes.find((r) => r.id === schedule.routeId)
                    const bus = buses.find((b) => b.id === schedule.busId)

                    return (
                      <TableRow key={schedule.id}>
                        <TableCell className="font-medium">{schedule.id}</TableCell>
                        <TableCell>{route?.name || "Unknown"}</TableCell>
                        <TableCell>{bus?.registrationNumber || "Unknown"}</TableCell>
                        <TableCell>{format(new Date(schedule.departureTime), "PPp")}</TableCell>
                        <TableCell>{format(new Date(schedule.arrivalTime), "PPp")}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              schedule.status === "completed"
                                ? "default"
                                : schedule.status === "cancelled"
                                  ? "destructive"
                                  : "warning"
                            }
                          >
                            {schedule.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {schedule.ticketsSold}/{schedule.capacity}
                        </TableCell>
                      </TableRow>
                    )
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
