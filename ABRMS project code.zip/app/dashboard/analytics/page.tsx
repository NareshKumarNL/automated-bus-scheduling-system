"use client"

import { useAppStore } from "@/lib/store"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { BarChart } from "@/components/charts/bar-chart"
import { LineChart } from "@/components/charts/line-chart"
import { PieChart } from "@/components/charts/pie-chart"
import { BarChart3, LineChartIcon, PieChartIcon, Download, Share2, RefreshCw } from "lucide-react"

export default function AnalyticsPage() {
  const { analytics } = useAppStore()

  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

  return (
    <div className="flex-1 space-y-4 p-4 pt-6 md:p-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">Analytics Dashboard</h2>
          <p className="text-slate-600">View detailed performance metrics and insights</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="border-slate-200 text-slate-700 hover:bg-slate-50">
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button variant="outline" className="border-slate-200 text-slate-700 hover:bg-slate-50">
            <Share2 className="mr-2 h-4 w-4" />
            Share
          </Button>
          <Button variant="outline" className="border-slate-200 text-slate-700 hover:bg-slate-50">
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-700">Total Revenue</CardTitle>
            <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
              <LineChartIcon className="h-4 w-4 text-green-600" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">₹{analytics.revenue.toLocaleString()}</div>
            <div className="flex items-center text-xs text-green-600">
              <span>+12.5% from last month</span>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-700">Passenger Count</CardTitle>
            <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
              <BarChart3 className="h-4 w-4 text-blue-600" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">{analytics.passengerCount.toLocaleString()}</div>
            <div className="flex items-center text-xs text-green-600">
              <span>+8.2% from last month</span>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-700">On-Time Performance</CardTitle>
            <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center">
              <PieChartIcon className="h-4 w-4 text-purple-600" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">{analytics.onTimePerformance}%</div>
            <div className="flex items-center text-xs text-green-600">
              <span>+2.3% from last month</span>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-md hover:shadow-lg transition-shadow">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-700">Fuel Efficiency</CardTitle>
            <div className="h-8 w-8 rounded-full bg-orange-100 flex items-center justify-center">
              <LineChartIcon className="h-4 w-4 text-orange-600" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-slate-900">{analytics.fuelEfficiency} km/L</div>
            <div className="flex items-center text-xs text-green-600">
              <span>+0.3 km/L improvement</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="bg-slate-100 p-1">
          <TabsTrigger value="overview" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            Overview
          </TabsTrigger>
          <TabsTrigger value="revenue" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            Revenue
          </TabsTrigger>
          <TabsTrigger value="passengers" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            Passengers
          </TabsTrigger>
          <TabsTrigger value="performance" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
            Performance
          </TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <Card className="border-none shadow-md">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
              <CardTitle>Performance Overview</CardTitle>
              <CardDescription className="text-blue-100">Key performance indicators across all metrics</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="w-full h-[400px] flex items-center justify-center">
                <LineChart
                  data={analytics.monthlyRevenue.map((val) => val / 1000000)}
                  labels={months}
                  title="Monthly Revenue (in Millions ₹)"
                  width={800}
                  height={350}
                  lineColor="#4f46e5"
                  fillColor="rgba(79, 70, 229, 0.1)"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="revenue" className="space-y-4">
          <Card className="border-none shadow-md">
            <CardHeader className="bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-t-lg">
              <CardTitle>Revenue Analysis</CardTitle>
              <CardDescription className="text-green-100">
                Detailed breakdown of revenue streams and trends
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="w-full h-[400px] flex items-center justify-center">
                <BarChart
                  data={analytics.monthlyRevenue.map((val) => val / 1000000)}
                  labels={months}
                  title="Monthly Revenue (in Millions ₹)"
                  width={800}
                  height={350}
                  color="#22c55e"
                  barColor="#4ade80"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="passengers" className="space-y-4">
          <Card className="border-none shadow-md">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-t-lg">
              <CardTitle>Passenger Metrics</CardTitle>
              <CardDescription className="text-blue-100">Passenger volume and demographic analysis</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="w-full h-[400px] flex items-center justify-center">
                <BarChart
                  data={analytics.monthlyPassengers.map((val) => val / 1000)}
                  labels={months}
                  title="Monthly Passenger Count (in Thousands)"
                  width={800}
                  height={350}
                  color="#0ea5e9"
                  barColor="#7dd3fc"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="performance" className="space-y-4">
          <Card className="border-none shadow-md">
            <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-t-lg">
              <CardTitle>Operational Performance</CardTitle>
              <CardDescription className="text-purple-100">
                On-time performance and service quality metrics
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="w-full h-[400px] flex items-center justify-center">
                <BarChart
                  data={analytics.routePerformance.map((item) => item.performance)}
                  labels={analytics.routePerformance.map((item) => `Route ${item.route}`)}
                  title="On-Time Performance by Route (%)"
                  width={800}
                  height={350}
                  color="#a855f7"
                  barColor="#d8b4fe"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-none shadow-md">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
            <CardTitle>Route Performance</CardTitle>
            <CardDescription className="text-blue-100">Performance metrics by route</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="w-full h-[300px] flex items-center justify-center">
              <PieChart
                data={analytics.routePerformance.map((item) => item.performance)}
                labels={analytics.routePerformance.map((item) => `Route ${item.route}`)}
                title="On-Time Performance by Route"
                width={300}
                height={300}
              />
            </div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-md">
          <CardHeader className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-t-lg">
            <CardTitle>Fleet Utilization</CardTitle>
            <CardDescription className="text-emerald-100">Bus utilization and efficiency metrics</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="w-full h-[300px] flex items-center justify-center">
              <PieChart
                data={analytics.fleetUtilization.map((item) => item.utilization)}
                labels={analytics.fleetUtilization.map((item) => item.busType)}
                title="Fleet Utilization by Bus Type (%)"
                width={300}
                height={300}
                colors={["#10b981", "#14b8a6", "#06b6d4"]}
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
