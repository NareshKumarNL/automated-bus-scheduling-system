"use client"

import { useState } from "react"
import { useAppStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Edit, Trash, UserPlus, X, AlertCircle } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export default function CrewsPage() {
  const { crews, addCrew, updateCrew, deleteCrew } = useAppStore()
  const [searchQuery, setSearchQuery] = useState("")
  const [filterRole, setFilterRole] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")
  const [newCrew, setNewCrew] = useState({
    name: "",
    employeeId: "",
    role: "Driver",
  })
  const [editingCrew, setEditingCrew] = useState(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [crewToDelete, setCrewToDelete] = useState(null)

  // Apply filters and search
  const filteredCrews = crews.filter((crew) => {
    const matchesSearch =
      crew.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      crew.employeeId.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesRole = filterRole === "all" || crew.role === filterRole
    const matchesStatus =
      filterStatus === "all" ||
      (filterStatus === "available" && crew.isAvailable) ||
      (filterStatus === "onDuty" && !crew.isAvailable)

    return matchesSearch && matchesRole && matchesStatus
  })

  const handleAddCrew = () => {
    addCrew({
      name: newCrew.name,
      employeeId: newCrew.employeeId,
      role: newCrew.role,
      isAvailable: true,
      lastAssignment: null,
      dailyAssignments: 0,
    })
    setNewCrew({ name: "", employeeId: "", role: "Driver" })
    setIsAddDialogOpen(false)
  }

  const handleEditCrew = () => {
    updateCrew(editingCrew.id, editingCrew)
    setIsEditDialogOpen(false)
    setEditingCrew(null)
  }

  const handleDeleteCrew = () => {
    if (crewToDelete) {
      deleteCrew(crewToDelete.id)
      setIsDeleteDialogOpen(false)
      setCrewToDelete(null)
    }
  }

  const formatDateTime = (dateTimeStr) => {
    if (!dateTimeStr) return "Not assigned yet"
    const date = new Date(dateTimeStr)
    return date.toLocaleString()
  }

  const resetFilters = () => {
    setSearchQuery("")
    setFilterRole("all")
    setFilterStatus("all")
  }

  return (
    <div className="flex-1 space-y-4 p-4 pt-6 md:p-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">Crew Management</h2>
          <p className="text-slate-600">Manage your drivers and conductors</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white">
              <UserPlus className="mr-2 h-4 w-4" />
              Add Crew Member
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-white border-none shadow-xl">
            <DialogHeader>
              <DialogTitle className="text-slate-900">Add New Crew Member</DialogTitle>
              <DialogDescription className="text-slate-600">
                Enter the details of the new crew member.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name" className="text-slate-700">
                  Name
                </Label>
                <Input
                  id="name"
                  placeholder="Enter full name"
                  value={newCrew.name}
                  onChange={(e) => setNewCrew({ ...newCrew, name: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="employeeId" className="text-slate-700">
                  Employee ID
                </Label>
                <Input
                  id="employeeId"
                  placeholder="e.g., ST-D-1004"
                  value={newCrew.employeeId}
                  onChange={(e) => setNewCrew({ ...newCrew, employeeId: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="role" className="text-slate-700">
                  Role
                </Label>
                <Select value={newCrew.role} onValueChange={(value) => setNewCrew({ ...newCrew, role: value })}>
                  <SelectTrigger id="role" className="border-slate-200 focus:ring-blue-500">
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    <SelectItem value="Driver">Driver</SelectItem>
                    <SelectItem value="Conductor">Conductor</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsAddDialogOpen(false)}
                className="border-slate-200 text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddCrew}
                disabled={!newCrew.name || !newCrew.employeeId}
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
              >
                Add Crew Member
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      <Card className="border-none shadow-md">
        <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
          <CardTitle>Crew Members</CardTitle>
          <CardDescription className="text-blue-100">
            Manage driver and conductor assignments and availability
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col space-y-4 md:flex-row md:items-center md:space-y-0 gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
              <Input
                type="search"
                placeholder="Search by name or ID..."
                className="pl-8 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <Select value={filterRole} onValueChange={setFilterRole}>
                <SelectTrigger className="w-[150px] border-slate-200 focus:ring-blue-500">
                  <SelectValue placeholder="Filter by role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Roles</SelectItem>
                  <SelectItem value="Driver">Drivers</SelectItem>
                  <SelectItem value="Conductor">Conductors</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-[150px] border-slate-200 focus:ring-blue-500">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="available">Available</SelectItem>
                  <SelectItem value="onDuty">On Duty</SelectItem>
                </SelectContent>
              </Select>

              <Button
                variant="outline"
                className="border-slate-200 text-slate-700 hover:bg-slate-50"
                onClick={resetFilters}
              >
                <X className="mr-2 h-4 w-4" />
                Reset
              </Button>
            </div>
          </div>
          <div className="rounded-md border border-slate-200 overflow-hidden">
            <Table>
              <TableHeader className="bg-slate-50">
                <TableRow className="hover:bg-slate-100/50">
                  <TableHead className="text-slate-700">Employee ID</TableHead>
                  <TableHead className="text-slate-700">Name</TableHead>
                  <TableHead className="text-slate-700">Role</TableHead>
                  <TableHead className="text-slate-700">Status</TableHead>
                  <TableHead className="text-slate-700">Last Assignment</TableHead>
                  <TableHead className="text-slate-700">Daily Assignments</TableHead>
                  <TableHead className="text-right text-slate-700">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCrews.length > 0 ? (
                  filteredCrews.map((crew) => (
                    <TableRow key={crew.id} className="hover:bg-slate-50">
                      <TableCell className="text-slate-700">{crew.employeeId}</TableCell>
                      <TableCell className="font-medium text-slate-800">{crew.name}</TableCell>
                      <TableCell className="text-slate-700">{crew.role}</TableCell>
                      <TableCell>
                        <Badge
                          variant={crew.isAvailable ? "outline" : "secondary"}
                          className={
                            crew.isAvailable
                              ? "bg-green-50 text-green-700 border-green-200"
                              : "bg-blue-50 text-blue-700 border-blue-200"
                          }
                        >
                          {crew.isAvailable ? "Available" : "On Duty"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-slate-700">{formatDateTime(crew.lastAssignment)}</TableCell>
                      <TableCell>
                        <Badge
                          variant={crew.dailyAssignments >= 4 ? "destructive" : "outline"}
                          className={
                            crew.dailyAssignments >= 4
                              ? "bg-red-50 text-red-700 border-red-200"
                              : "bg-slate-50 text-slate-700 border-slate-200"
                          }
                        >
                          {crew.dailyAssignments}/5
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-slate-600 hover:text-blue-600 hover:bg-blue-50"
                            onClick={() => {
                              setEditingCrew({ ...crew })
                              setIsEditDialogOpen(true)
                            }}
                          >
                            <Edit className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-slate-600 hover:text-red-600 hover:bg-red-50"
                            onClick={() => {
                              setCrewToDelete(crew)
                              setIsDeleteDialogOpen(true)
                            }}
                          >
                            <Trash className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      <div className="flex flex-col items-center justify-center text-slate-500">
                        <AlertCircle className="h-8 w-8 mb-2" />
                        <p>No crew members found</p>
                        <p className="text-sm">Try adjusting your search or filters</p>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-white border-none shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-slate-900">Edit Crew Member</DialogTitle>
            <DialogDescription className="text-slate-600">Make changes to the crew member details.</DialogDescription>
          </DialogHeader>
          {editingCrew && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-name" className="text-slate-700">
                  Name
                </Label>
                <Input
                  id="edit-name"
                  placeholder="Enter full name"
                  value={editingCrew.name}
                  onChange={(e) => setEditingCrew({ ...editingCrew, name: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-employeeId" className="text-slate-700">
                  Employee ID
                </Label>
                <Input
                  id="edit-employeeId"
                  placeholder="e.g., ST-D-1004"
                  value={editingCrew.employeeId}
                  onChange={(e) => setEditingCrew({ ...editingCrew, employeeId: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-role" className="text-slate-700">
                  Role
                </Label>
                <Select
                  value={editingCrew.role}
                  onValueChange={(value) => setEditingCrew({ ...editingCrew, role: value })}
                >
                  <SelectTrigger id="edit-role" className="border-slate-200 focus:ring-blue-500">
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    <SelectItem value="Driver">Driver</SelectItem>
                    <SelectItem value="Conductor">Conductor</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-status" className="text-slate-700">
                  Status
                </Label>
                <Select
                  value={editingCrew.isAvailable ? "available" : "onDuty"}
                  onValueChange={(value) =>
                    setEditingCrew({
                      ...editingCrew,
                      isAvailable: value === "available",
                    })
                  }
                >
                  <SelectTrigger id="edit-status" className="border-slate-200 focus:ring-blue-500">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    <SelectItem value="available">Available</SelectItem>
                    <SelectItem value="onDuty">On Duty</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsEditDialogOpen(false)}
              className="border-slate-200 text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </Button>
            <Button
              onClick={handleEditCrew}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the crew member
              {crewToDelete ? ` ${crewToDelete.name} (${crewToDelete.employeeId})` : ""}. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteCrew} className="bg-red-600 hover:bg-red-700 text-white">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
