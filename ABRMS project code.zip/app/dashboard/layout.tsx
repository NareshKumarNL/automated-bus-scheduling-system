import type { ReactNode } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Bus, Calendar, Home, LogOut, MapPin, Menu, Users, AlertTriangle, BarChart3, Settings } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function DashboardLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col bg-slate-50">
      <header className="sticky top-0 z-50 w-full border-b bg-white shadow-sm">
        <div className="container flex h-16 items-center">
          <div className="flex items-center space-x-2">
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-1.5 rounded-md">
              <Bus className="h-5 w-5 text-white" />
            </div>
            <span className="font-bold hidden md:inline-flex text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
              SmartTransit
            </span>
          </div>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="ml-2 md:hidden border-slate-200 text-slate-700">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-64 sm:max-w-none bg-white border-r border-slate-200 p-0">
              <div className="flex items-center space-x-2 p-4 border-b border-slate-100">
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-1.5 rounded-md">
                  <Bus className="h-5 w-5 text-white" />
                </div>
                <span className="font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
                  SmartTransit
                </span>
              </div>
              <div className="py-4">
                <div className="px-3 pb-1">
                  <h3 className="text-xs font-medium text-slate-500 uppercase tracking-wider">Main</h3>
                </div>
                <nav className="grid gap-1 px-2">
                  <Link
                    href="/dashboard"
                    className="flex items-center gap-3 rounded-md px-3 py-2 text-slate-700 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                  >
                    <Home className="h-5 w-5" />
                    <span>Dashboard</span>
                  </Link>
                  <Link
                    href="/dashboard/crews"
                    className="flex items-center gap-3 rounded-md px-3 py-2 text-slate-700 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                  >
                    <Users className="h-5 w-5" />
                    <span>Crew Management</span>
                  </Link>
                  <Link
                    href="/dashboard/buses"
                    className="flex items-center gap-3 rounded-md px-3 py-2 text-slate-700 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                  >
                    <Bus className="h-5 w-5" />
                    <span>Fleet Management</span>
                  </Link>
                  <Link
                    href="/dashboard/routes"
                    className="flex items-center gap-3 rounded-md px-3 py-2 text-slate-700 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                  >
                    <MapPin className="h-5 w-5" />
                    <span>Route Management</span>
                  </Link>
                </nav>

                <div className="px-3 pt-4 pb-1">
                  <h3 className="text-xs font-medium text-slate-500 uppercase tracking-wider">Operations</h3>
                </div>
                <nav className="grid gap-1 px-2">
                  <Link
                    href="/dashboard/schedules"
                    className="flex items-center gap-3 rounded-md px-3 py-2 text-slate-700 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                  >
                    <Calendar className="h-5 w-5" />
                    <span>Scheduling</span>
                  </Link>
                  <Link
                    href="/dashboard/emergency"
                    className="flex items-center gap-3 rounded-md px-3 py-2 text-slate-700 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                  >
                    <AlertTriangle className="h-5 w-5" />
                    <span>Emergency Response</span>
                  </Link>
                  <Link
                    href="/dashboard/analytics"
                    className="flex items-center gap-3 rounded-md px-3 py-2 text-slate-700 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                  >
                    <BarChart3 className="h-5 w-5" />
                    <span>Analytics</span>
                  </Link>
                  <Link
                    href="/dashboard/settings"
                    className="flex items-center gap-3 rounded-md px-3 py-2 text-slate-700 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                  >
                    <Settings className="h-5 w-5" />
                    <span>Settings</span>
                  </Link>
                </nav>
              </div>
            </SheetContent>
          </Sheet>
          <nav className="mx-6 hidden md:flex items-center space-x-4 lg:space-x-6">
            <Link
              href="/dashboard"
              className="text-sm font-medium transition-colors hover:text-blue-600 text-slate-700"
            >
              Dashboard
            </Link>
            <Link
              href="/dashboard/crews"
              className="text-sm font-medium text-slate-600 transition-colors hover:text-blue-600"
            >
              Crews
            </Link>
            <Link
              href="/dashboard/buses"
              className="text-sm font-medium text-slate-600 transition-colors hover:text-blue-600"
            >
              Fleet
            </Link>
            <Link
              href="/dashboard/routes"
              className="text-sm font-medium text-slate-600 transition-colors hover:text-blue-600"
            >
              Routes
            </Link>
            <Link
              href="/dashboard/schedules"
              className="text-sm font-medium text-slate-600 transition-colors hover:text-blue-600"
            >
              Schedules
            </Link>
            <Link
              href="/dashboard/emergency"
              className="text-sm font-medium text-slate-600 transition-colors hover:text-blue-600"
            >
              Emergency
            </Link>
          </nav>
          <div className="ml-auto flex items-center space-x-4">
            <Link href="/">
              <Button
                variant="ghost"
                size="icon"
                className="text-slate-700 hover:text-blue-600 hover:bg-blue-50 transition-colors"
              >
                <LogOut className="h-5 w-5" />
                <span className="sr-only">Logout</span>
              </Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">{children}</main>
    </div>
  )
}
