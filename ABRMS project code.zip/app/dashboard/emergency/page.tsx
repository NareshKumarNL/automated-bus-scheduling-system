"use client"

import { useState } from "react"
import { useAppStore } from "@/lib/store"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { AlertTriangle, AlertCircle, Edit, Trash, Search, X, Check } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export default function EmergencyPage() {
  const { emergencies, buses, addEmergency, updateEmergency, deleteEmergency } = useAppStore()
  const [newEmergency, setNewEmergency] = useState({
    type: "",
    busNumber: "",
    location: "",
    description: "",
  })
  const [searchQuery, setSearchQuery] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingEmergency, setEditingEmergency] = useState(null)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [emergencyToDelete, setEmergencyToDelete] = useState(null)
  const [isResolveDialogOpen, setIsResolveDialogOpen] = useState(false)
  const [emergencyToResolve, setEmergencyToResolve] = useState(null)

  // Filter emergencies
  const filteredEmergencies = emergencies
    .filter((emergency) => {
      const matchesSearch =
        emergency.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emergency.busNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emergency.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        emergency.description.toLowerCase().includes(searchQuery.toLowerCase())

      const matchesType = filterType === "all" || emergency.type === filterType
      const matchesStatus = filterStatus === "all" || emergency.status === filterStatus

      return matchesSearch && matchesType && matchesStatus
    })
    .sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime())

  const handleEmergencySubmit = (e) => {
    e.preventDefault()
    addEmergency({
      type: newEmergency.type,
      busNumber: newEmergency.busNumber,
      location: newEmergency.location,
      description: newEmergency.description,
    })
    setNewEmergency({
      type: "",
      busNumber: "",
      location: "",
      description: "",
    })
  }

  const handleEditEmergency = () => {
    if (editingEmergency) {
      updateEmergency(editingEmergency.id, editingEmergency)
      setIsEditDialogOpen(false)
      setEditingEmergency(null)
    }
  }

  const handleDeleteEmergency = () => {
    if (emergencyToDelete) {
      deleteEmergency(emergencyToDelete.id)
      setIsDeleteDialogOpen(false)
      setEmergencyToDelete(null)
    }
  }

  const handleResolveEmergency = () => {
    if (emergencyToResolve) {
      const resolvedEmergency = {
        ...emergencyToResolve,
        status: "Resolved",
        resolvedTime: new Date().toISOString(),
      }
      updateEmergency(emergencyToResolve.id, resolvedEmergency)
      setIsResolveDialogOpen(false)
      setEmergencyToResolve(null)
    }
  }

  const formatDateTime = (dateTimeStr) => {
    if (!dateTimeStr) return ""
    const date = new Date(dateTimeStr)
    return date.toLocaleString()
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "Resolved":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            Resolved
          </Badge>
        )
      case "In Progress":
        return (
          <Badge variant="secondary" className="bg-blue-50 text-blue-700 border-blue-200">
            In Progress
          </Badge>
        )
      default:
        return <Badge>{status}</Badge>
    }
  }

  const getEmergencyTypeBadge = (type) => {
    switch (type) {
      case "Breakdown":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            Breakdown
          </Badge>
        )
      case "Accident":
        return (
          <Badge variant="destructive" className="bg-red-50 text-red-700 border-red-200">
            Accident
          </Badge>
        )
      case "Medical":
        return (
          <Badge variant="secondary" className="bg-purple-50 text-purple-700 border-purple-200">
            Medical
          </Badge>
        )
      case "Traffic":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            Traffic
          </Badge>
        )
      default:
        return (
          <Badge variant="outline" className="bg-slate-50 text-slate-700 border-slate-200">
            {type}
          </Badge>
        )
    }
  }

  const resetFilters = () => {
    setSearchQuery("")
    setFilterType("all")
    setFilterStatus("all")
  }

  return (
    <div className="flex-1 space-y-4 p-4 pt-6 md:p-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">Emergency Response</h2>
          <p className="text-slate-600">Manage and respond to emergency situations</p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-none shadow-md">
          <CardHeader className="bg-gradient-to-r from-red-600 to-orange-600 text-white rounded-t-lg">
            <CardTitle>Report Emergency</CardTitle>
            <CardDescription className="text-red-100">
              Report a new emergency situation for immediate handling
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleEmergencySubmit}>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="type" className="text-slate-700">
                  Emergency Type
                </Label>
                <Select
                  value={newEmergency.type}
                  onValueChange={(value) => setNewEmergency({ ...newEmergency, type: value })}
                  required
                >
                  <SelectTrigger id="type" className="border-slate-200 focus:ring-red-500">
                    <SelectValue placeholder="Select emergency type" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    <SelectItem value="Breakdown">Vehicle Breakdown</SelectItem>
                    <SelectItem value="Accident">Accident</SelectItem>
                    <SelectItem value="Medical">Medical Emergency</SelectItem>
                    <SelectItem value="Traffic">Severe Traffic</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="busNumber" className="text-slate-700">
                  Bus Number
                </Label>
                <Select
                  value={newEmergency.busNumber}
                  onValueChange={(value) => setNewEmergency({ ...newEmergency, busNumber: value })}
                  required
                >
                  <SelectTrigger id="busNumber" className="border-slate-200 focus:ring-red-500">
                    <SelectValue placeholder="Select bus number" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    {buses.map((bus) => (
                      <SelectItem key={bus.id} value={bus.busNumber}>
                        {bus.busNumber} - {bus.model}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="location" className="text-slate-700">
                  Location
                </Label>
                <Input
                  id="location"
                  placeholder="e.g., Chennai Central"
                  value={newEmergency.location}
                  onChange={(e) => setNewEmergency({ ...newEmergency, location: e.target.value })}
                  required
                  className="border-slate-200 focus:border-red-500 focus:ring-red-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description" className="text-slate-700">
                  Description
                </Label>
                <Textarea
                  id="description"
                  placeholder="Describe the emergency situation..."
                  value={newEmergency.description}
                  onChange={(e) => setNewEmergency({ ...newEmergency, description: e.target.value })}
                  required
                  className="border-slate-200 focus:border-red-500 focus:ring-red-500"
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 text-white"
                disabled={
                  !newEmergency.type || !newEmergency.busNumber || !newEmergency.location || !newEmergency.description
                }
              >
                <AlertTriangle className="mr-2 h-4 w-4" />
                Report Emergency
              </Button>
            </CardFooter>
          </form>
        </Card>
        <Card className="border-none shadow-md">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
            <CardTitle>Emergency Response Guidelines</CardTitle>
            <CardDescription className="text-blue-100">
              Follow these guidelines when handling emergency situations
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="border-orange-200 bg-orange-50">
              <AlertCircle className="h-4 w-4 text-orange-600" />
              <AlertTitle className="text-orange-800">Vehicle Breakdown</AlertTitle>
              <AlertDescription className="text-orange-700">
                1. Ensure passenger safety
                <br />
                2. Move vehicle to safe location if possible
                <br />
                3. Report exact location and issue
                <br />
                4. Request replacement vehicle
              </AlertDescription>
            </Alert>
            <Alert className="border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertTitle className="text-red-800">Accident</AlertTitle>
              <AlertDescription className="text-red-700">
                1. Check for injuries and provide first aid
                <br />
                2. Contact emergency services if needed
                <br />
                3. Document the incident with photos
                <br />
                4. Collect witness information
              </AlertDescription>
            </Alert>
            <Alert className="border-blue-200 bg-blue-50">
              <AlertCircle className="h-4 w-4 text-blue-600" />
              <AlertTitle className="text-blue-800">Medical Emergency</AlertTitle>
              <AlertDescription className="text-blue-700">
                1. Assess the situation and provide first aid
                <br />
                2. Call for medical assistance
                <br />
                3. Keep the affected person comfortable
                <br />
                4. Clear the area to allow medical access
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>
      <Card className="border-none shadow-md">
        <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
          <CardTitle>Emergency Logs</CardTitle>
          <CardDescription className="text-blue-100">Recent emergency reports and their status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col space-y-4 md:flex-row md:items-center md:space-y-0 gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
              <Input
                type="search"
                placeholder="Search emergency logs..."
                className="pl-8 border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-[150px] border-slate-200 focus:ring-blue-500">
                  <SelectValue placeholder="Filter by type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="Breakdown">Breakdown</SelectItem>
                  <SelectItem value="Accident">Accident</SelectItem>
                  <SelectItem value="Medical">Medical</SelectItem>
                  <SelectItem value="Traffic">Traffic</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>

              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-[150px] border-slate-200 focus:ring-blue-500">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="Resolved">Resolved</SelectItem>
                </SelectContent>
              </Select>

              <Button
                variant="outline"
                className="border-slate-200 text-slate-700 hover:bg-slate-50"
                onClick={resetFilters}
              >
                <X className="mr-2 h-4 w-4" />
                Reset
              </Button>
            </div>
          </div>
          <div className="rounded-md border border-slate-200 overflow-hidden">
            <Table>
              <TableHeader className="bg-slate-50">
                <TableRow className="hover:bg-slate-100/50">
                  <TableHead className="text-slate-700">Type</TableHead>
                  <TableHead className="text-slate-700">Bus Number</TableHead>
                  <TableHead className="text-slate-700">Location</TableHead>
                  <TableHead className="text-slate-700">Reported Time</TableHead>
                  <TableHead className="text-slate-700">Status</TableHead>
                  <TableHead className="text-slate-700">Description</TableHead>
                  <TableHead className="text-right text-slate-700">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredEmergencies.length > 0 ? (
                  filteredEmergencies.map((emergency) => (
                    <TableRow key={emergency.id} className="hover:bg-slate-50">
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <AlertTriangle
                            className={`h-4 w-4 ${emergency.status === "Resolved" ? "text-green-500" : "text-red-500"}`}
                          />
                          {getEmergencyTypeBadge(emergency.type)}
                        </div>
                      </TableCell>
                      <TableCell className="text-slate-700">{emergency.busNumber}</TableCell>
                      <TableCell className="text-slate-700">{emergency.location}</TableCell>
                      <TableCell className="text-slate-700">{formatDateTime(emergency.time)}</TableCell>
                      <TableCell>{getStatusBadge(emergency.status)}</TableCell>
                      <TableCell className="max-w-xs truncate text-slate-700">{emergency.description}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          {emergency.status === "In Progress" && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-slate-600 hover:text-green-600 hover:bg-green-50"
                              onClick={() => {
                                setEmergencyToResolve(emergency)
                                setIsResolveDialogOpen(true)
                              }}
                            >
                              <Check className="h-4 w-4" />
                              <span className="sr-only">Resolve</span>
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-slate-600 hover:text-blue-600 hover:bg-blue-50"
                            onClick={() => {
                              setEditingEmergency({ ...emergency })
                              setIsEditDialogOpen(true)
                            }}
                          >
                            <Edit className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-slate-600 hover:text-red-600 hover:bg-red-50"
                            onClick={() => {
                              setEmergencyToDelete(emergency)
                              setIsDeleteDialogOpen(true)
                            }}
                          >
                            <Trash className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      <div className="flex flex-col items-center justify-center text-slate-500">
                        <AlertCircle className="h-8 w-8 mb-2" />
                        <p>No emergency logs found</p>
                        <p className="text-sm">Try adjusting your search or filters</p>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Edit Emergency Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-white border-none shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-slate-900">Edit Emergency</DialogTitle>
            <DialogDescription className="text-slate-600">Update emergency details</DialogDescription>
          </DialogHeader>
          {editingEmergency && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-type" className="text-slate-700">
                  Emergency Type
                </Label>
                <Select
                  value={editingEmergency.type}
                  onValueChange={(value) => setEditingEmergency({ ...editingEmergency, type: value })}
                >
                  <SelectTrigger id="edit-type" className="border-slate-200 focus:ring-blue-500">
                    <SelectValue placeholder="Select emergency type" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    <SelectItem value="Breakdown">Vehicle Breakdown</SelectItem>
                    <SelectItem value="Accident">Accident</SelectItem>
                    <SelectItem value="Medical">Medical Emergency</SelectItem>
                    <SelectItem value="Traffic">Severe Traffic</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-busNumber" className="text-slate-700">
                  Bus Number
                </Label>
                <Select
                  value={editingEmergency.busNumber}
                  onValueChange={(value) => setEditingEmergency({ ...editingEmergency, busNumber: value })}
                >
                  <SelectTrigger id="edit-busNumber" className="border-slate-200 focus:ring-blue-500">
                    <SelectValue placeholder="Select bus number" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    {buses.map((bus) => (
                      <SelectItem key={bus.id} value={bus.busNumber}>
                        {bus.busNumber} - {bus.model}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-location" className="text-slate-700">
                  Location
                </Label>
                <Input
                  id="edit-location"
                  value={editingEmergency.location}
                  onChange={(e) => setEditingEmergency({ ...editingEmergency, location: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-status" className="text-slate-700">
                  Status
                </Label>
                <Select
                  value={editingEmergency.status}
                  onValueChange={(value) => setEditingEmergency({ ...editingEmergency, status: value })}
                >
                  <SelectTrigger id="edit-status" className="border-slate-200 focus:ring-blue-500">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    <SelectItem value="In Progress">In Progress</SelectItem>
                    <SelectItem value="Resolved">Resolved</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-description" className="text-slate-700">
                  Description
                </Label>
                <Textarea
                  id="edit-description"
                  value={editingEmergency.description}
                  onChange={(e) => setEditingEmergency({ ...editingEmergency, description: e.target.value })}
                  className="border-slate-200 focus:border-blue-500 focus:ring-blue-500"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsEditDialogOpen(false)}
              className="border-slate-200 text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </Button>
            <Button
              onClick={handleEditEmergency}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white"
            >
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Resolve Emergency Dialog */}
      <Dialog open={isResolveDialogOpen} onOpenChange={setIsResolveDialogOpen}>
        <DialogContent className="bg-white border-none shadow-xl">
          <DialogHeader>
            <DialogTitle className="text-slate-900">Resolve Emergency</DialogTitle>
            <DialogDescription className="text-slate-600">Mark this emergency as resolved</DialogDescription>
          </DialogHeader>
          {emergencyToResolve && (
            <div className="py-4">
              <div className="bg-green-50 p-4 rounded-lg border border-green-200 mb-4">
                <p className="font-medium text-green-800">You are about to resolve:</p>
                <p className="text-green-700 mt-1">
                  {emergencyToResolve.type} emergency for bus {emergencyToResolve.busNumber} at{" "}
                  {emergencyToResolve.location}
                </p>
              </div>
              <p className="text-slate-600">Resolving this emergency will:</p>
              <ul className="list-disc list-inside mt-2 text-slate-600">
                <li>Mark it as "Resolved" in the system</li>
                <li>Record the current time as resolution time</li>
                <li>Update analytics and reports</li>
              </ul>
            </div>
          )}
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsResolveDialogOpen(false)}
              className="border-slate-200 text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </Button>
            <Button
              onClick={handleResolveEmergency}
              className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white"
            >
              Resolve Emergency
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this emergency log
              {emergencyToDelete ? ` for ${emergencyToDelete.type} emergency at ${emergencyToDelete.location}` : ""}.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteEmergency} className="bg-red-600 hover:bg-red-700 text-white">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
