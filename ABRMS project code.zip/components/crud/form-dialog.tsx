"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

interface FormDialogProps {
  title: string
  description?: string
  triggerText: string
  triggerVariant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link"
  submitText?: string
  submitVariant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link"
  cancelText?: string
  onSubmit: () => void
  children: React.ReactNode
}

export function FormDialog({
  title,
  description,
  triggerText,
  triggerVariant = "default",
  submitText = "Save",
  submitVariant = "default",
  cancelText = "Cancel",
  onSubmit,
  children,
}: FormDialogProps) {
  const [open, setOpen] = useState(false)

  const handleSubmit = () => {
    onSubmit()
    setOpen(false)
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant={triggerVariant}>{triggerText}</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        <div className="py-4">{children}</div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            {cancelText}
          </Button>
          <Button variant={submitVariant} onClick={handleSubmit}>
            {submitText}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
