"use client"

import { useRef, useEffect } from "react"

interface BarChartProps {
  data: number[]
  labels: string[]
  height?: number
  width?: number
  title?: string
  color?: string
  barColor?: string
  className?: string
}

export function BarChart({
  data,
  labels,
  height = 300,
  width = 600,
  title = "",
  color = "#4f46e5",
  barColor = "#818cf8",
  className = "",
}: BarChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set canvas dimensions
    canvas.width = width
    canvas.height = height

    // Calculate max value for scaling
    const maxValue = Math.max(...data) * 1.1 // Add 10% padding

    // Calculate bar width and spacing
    const barCount = data.length
    const barWidth = (width - 60) / barCount - 10
    const startX = 40

    // Draw title
    if (title) {
      ctx.fillStyle = "#1e293b"
      ctx.font = "16px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(title, width / 2, 20)
    }

    // Draw y-axis
    ctx.beginPath()
    ctx.moveTo(startX, 40)
    ctx.lineTo(startX, height - 40)
    ctx.strokeStyle = "#cbd5e1"
    ctx.stroke()

    // Draw x-axis
    ctx.beginPath()
    ctx.moveTo(startX, height - 40)
    ctx.lineTo(width - 20, height - 40)
    ctx.strokeStyle = "#cbd5e1"
    ctx.stroke()

    // Draw y-axis labels
    ctx.fillStyle = "#64748b"
    ctx.font = "12px sans-serif"
    ctx.textAlign = "right"

    const yLabelCount = 5
    for (let i = 0; i <= yLabelCount; i++) {
      const value = (maxValue * i) / yLabelCount
      const y = height - 40 - ((height - 80) * i) / yLabelCount
      ctx.fillText(value.toLocaleString(), startX - 5, y + 4)

      // Draw horizontal grid lines
      ctx.beginPath()
      ctx.moveTo(startX, y)
      ctx.lineTo(width - 20, y)
      ctx.strokeStyle = "#e2e8f0"
      ctx.stroke()
    }

    // Draw bars and x-axis labels
    data.forEach((value, index) => {
      const x = startX + index * (barWidth + 10) + 10
      const barHeight = ((height - 80) * value) / maxValue
      const y = height - 40 - barHeight

      // Create gradient for bar
      const gradient = ctx.createLinearGradient(x, y, x, height - 40)
      gradient.addColorStop(0, color)
      gradient.addColorStop(1, barColor)

      // Draw bar
      ctx.fillStyle = gradient
      ctx.fillRect(x, y, barWidth, barHeight)

      // Draw bar border
      ctx.strokeStyle = color
      ctx.strokeRect(x, y, barWidth, barHeight)

      // Draw x-axis label
      ctx.fillStyle = "#64748b"
      ctx.font = "12px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(labels[index], x + barWidth / 2, height - 20)
    })
  }, [data, labels, height, width, title, color, barColor])

  return <canvas ref={canvasRef} className={className} />
}
