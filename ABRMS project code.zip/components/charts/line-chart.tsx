"use client"

import { useRef, useEffect } from "react"

interface LineChartProps {
  data: number[]
  labels: string[]
  height?: number
  width?: number
  title?: string
  lineColor?: string
  fillColor?: string
  className?: string
}

export function LineChart({
  data,
  labels,
  height = 300,
  width = 600,
  title = "",
  lineColor = "#4f46e5",
  fillColor = "rgba(79, 70, 229, 0.1)",
  className = "",
}: LineChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set canvas dimensions
    canvas.width = width
    canvas.height = height

    // Calculate max value for scaling
    const maxValue = Math.max(...data) * 1.1 // Add 10% padding

    // Calculate point spacing
    const pointCount = data.length
    const pointSpacing = (width - 60) / (pointCount - 1)
    const startX = 40

    // Draw title
    if (title) {
      ctx.fillStyle = "#1e293b"
      ctx.font = "16px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(title, width / 2, 20)
    }

    // Draw y-axis
    ctx.beginPath()
    ctx.moveTo(startX, 40)
    ctx.lineTo(startX, height - 40)
    ctx.strokeStyle = "#cbd5e1"
    ctx.stroke()

    // Draw x-axis
    ctx.beginPath()
    ctx.moveTo(startX, height - 40)
    ctx.lineTo(width - 20, height - 40)
    ctx.strokeStyle = "#cbd5e1"
    ctx.stroke()

    // Draw y-axis labels
    ctx.fillStyle = "#64748b"
    ctx.font = "12px sans-serif"
    ctx.textAlign = "right"

    const yLabelCount = 5
    for (let i = 0; i <= yLabelCount; i++) {
      const value = (maxValue * i) / yLabelCount
      const y = height - 40 - ((height - 80) * i) / yLabelCount
      ctx.fillText(value.toLocaleString(), startX - 5, y + 4)

      // Draw horizontal grid lines
      ctx.beginPath()
      ctx.moveTo(startX, y)
      ctx.lineTo(width - 20, y)
      ctx.strokeStyle = "#e2e8f0"
      ctx.stroke()
    }

    // Draw line and points
    ctx.beginPath()
    data.forEach((value, index) => {
      const x = startX + index * pointSpacing
      const y = height - 40 - ((height - 80) * value) / maxValue

      if (index === 0) {
        ctx.moveTo(x, y)
      } else {
        ctx.lineTo(x, y)
      }

      // Draw x-axis label
      ctx.fillStyle = "#64748b"
      ctx.font = "12px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(labels[index], x, height - 20)
    })

    // Stroke the line
    ctx.strokeStyle = lineColor
    ctx.lineWidth = 2
    ctx.stroke()

    // Fill area under the line
    ctx.lineTo(startX + (pointCount - 1) * pointSpacing, height - 40)
    ctx.lineTo(startX, height - 40)
    ctx.fillStyle = fillColor
    ctx.fill()

    // Draw points
    data.forEach((value, index) => {
      const x = startX + index * pointSpacing
      const y = height - 40 - ((height - 80) * value) / maxValue

      ctx.beginPath()
      ctx.arc(x, y, 4, 0, Math.PI * 2)
      ctx.fillStyle = lineColor
      ctx.fill()
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 1
      ctx.stroke()
    })
  }, [data, labels, height, width, title, lineColor, fillColor])

  return <canvas ref={canvasRef} className={className} />
}
