"use client"

import { useRef, useEffect } from "react"

interface PieChartProps {
  data: number[]
  labels: string[]
  height?: number
  width?: number
  title?: string
  colors?: string[]
  className?: string
}

export function PieChart({
  data,
  labels,
  height = 300,
  width = 300,
  title = "",
  colors = ["#4f46e5", "#8b5cf6", "#ec4899", "#f97316", "#22c55e", "#06b6d4"],
  className = "",
}: PieChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set canvas dimensions
    canvas.width = width
    canvas.height = height

    // Calculate total value
    const total = data.reduce((sum, value) => sum + value, 0)

    // Draw title
    if (title) {
      ctx.fillStyle = "#1e293b"
      ctx.font = "16px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(title, width / 2, 20)
    }

    // Draw pie chart
    const radius = Math.min(width, height) / 2 - 40
    const centerX = width / 2
    const centerY = height / 2

    let startAngle = 0
    data.forEach((value, index) => {
      const sliceAngle = (2 * Math.PI * value) / total
      const endAngle = startAngle + sliceAngle

      // Draw slice
      ctx.beginPath()
      ctx.moveTo(centerX, centerY)
      ctx.arc(centerX, centerY, radius, startAngle, endAngle)
      ctx.closePath()

      // Fill slice
      ctx.fillStyle = colors[index % colors.length]
      ctx.fill()

      // Draw slice border
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 2
      ctx.stroke()

      // Calculate label position
      const labelAngle = startAngle + sliceAngle / 2
      const labelRadius = radius * 0.7
      const labelX = centerX + labelRadius * Math.cos(labelAngle)
      const labelY = centerY + labelRadius * Math.sin(labelAngle)

      // Draw percentage label
      const percentage = Math.round((value / total) * 100)
      ctx.fillStyle = "#ffffff"
      ctx.font = "bold 12px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      if (percentage > 5) {
        ctx.fillText(`${percentage}%`, labelX, labelY)
      }

      startAngle = endAngle
    })

    // Draw legend
    const legendX = width - 100
    const legendY = height - 20 - data.length * 20
    data.forEach((value, index) => {
      const y = legendY + index * 20

      // Draw legend color box
      ctx.fillStyle = colors[index % colors.length]
      ctx.fillRect(legendX, y, 15, 15)

      // Draw legend label
      ctx.fillStyle = "#64748b"
      ctx.font = "12px sans-serif"
      ctx.textAlign = "left"
      ctx.textBaseline = "middle"
      ctx.fillText(labels[index], legendX + 20, y + 7.5)
    })
  }, [data, labels, height, width, title, colors])

  return <canvas ref={canvasRef} className={className} />
}
